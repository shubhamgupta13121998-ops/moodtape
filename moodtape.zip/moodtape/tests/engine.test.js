'use strict';
const test = require('node:test');
const assert = require('node:assert');
const E = require('../public/js/engine.js');

const cases = [
  ['Reliance Industries Q2 net profit jumps 12%, beats street estimates', 'Bullish', 'RELIANCE'],
  ['TCS shares fall 3% after weak deal wins and muted revenue guidance', 'Bearish', 'TCS'],
  ['Infosys raises FY27 revenue guidance, announces buyback', 'Bullish', 'INFY'],
  ['Wipro fails to beat estimates; margins decline', 'Bearish', 'WIPRO'],
  ['Zomato surges after quarterly loss narrows sharply', 'Bullish', 'ETERNAL'],
  ['Sun Pharma gets USFDA warning letter for Halol plant', 'Bearish', 'SUNPHARMA'],
  ['Fed officials signal no rush to cut rates as inflation stays sticky', 'Bearish', 'FED'],
  ['Bank Nifty hits all-time high as private lenders gain', 'Bullish', 'BANKNIFTY'],
  ['Nifty, Sensex open flat ahead of US inflation data', 'Neutral', 'NIFTY'],
  ['L&T bags mega order worth over ₹10,000 crore', 'Bullish', 'LT'],
  ['Tesla recalls 200,000 vehicles over software glitch', 'Bearish', 'TSLA']
];
for (const [text, label, sym] of cases) {
  test(`scores "${text.slice(0, 40)}…" as ${label} and tags ${sym}`, () => {
    const a = E.analyze(text);
    assert.strictEqual(a.lex.label, label);
    assert.ok(a.syms.includes(sym), `expected ${sym} in ${a.syms}`);
    assert.ok(a.lex.score >= -1 && a.lex.score <= 1);
  });
}
test('negation flips a positive phrase', () => {
  const pos = E.scoreHeadline('Company beats estimates'), neg = E.scoreHeadline('Company fails to beat estimates');
  assert.ok(pos.score > 0 && neg.score < 0);
  assert.ok(neg.hits.some(h => h.neg));
});
test('concession clause is down-weighted', () => {
  assert.ok(E.scoreHeadline('Stock rises despite weak results').score > 0);
  assert.ok(E.scoreHeadline('Stock rises on weak results').score < E.scoreHeadline('Stock rises despite weak results').score);
});
test('negation does not leak past the previous signal', () => {
  const r = E.scoreHeadline('Fed signals no rush to cut rates as inflation stays sticky');
  assert.ok(r.hits.find(h => /sticky/.test(h.t)).neg === false);
});
test('case-sensitive short aliases do not match ordinary words', () => {
  assert.deepStrictEqual(E.extractEntities('The fed up investor sold his meta stake in a hal').syms, []);
});
test('longest alias wins: Bank Nifty is not Nifty', () => {
  assert.deepStrictEqual(E.extractEntities('Bank Nifty rallies').syms, ['BANKNIFTY']);
});
test('cashtags and exchange prefixes become symbols', () => {
  const r = E.extractEntities('$PLTR jumps; NSE:IRFC slides');
  assert.deepStrictEqual(r.syms, ['PLTR', 'IRFC']);
  assert.deepStrictEqual(r.extra.map(x => x.mkt), ['US', 'IN']);
});
test('summarize computes counts, mood and tickers', () => {
  const items = ['Infosys raises guidance', 'Infosys shares crash after fraud probe', 'Nifty ends flat'].map(t => ({ text: t, ...E.analyze(t) }));
  const s = E.summarize(items);
  assert.strictEqual(s.count, 3);
  assert.strictEqual(s.counts.Bullish + s.counts.Bearish + s.counts.Neutral, 3);
  assert.ok(s.mood >= 0 && s.mood <= 100);
  assert.strictEqual(s.tickers[0].sym, 'INFY');
  assert.strictEqual(s.tickers[0].n, 2);
});
test('AI result overrides instant score', () => {
  const it = { text: 'x', ...E.analyze('Airtel tariff hike'), ai: { score: 0.7, label: 'Bullish', impact: 'high' } };
  assert.strictEqual(E.effective(it).src, 'ai');
  assert.strictEqual(E.effective(it).score, 0.7);
});
