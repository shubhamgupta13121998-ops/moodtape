'use strict';
// End-to-end tests of the API handlers with Supabase, Stripe, the AI provider and news feeds faked in memory.
const test = require('node:test');
const assert = require('node:assert');
const crypto = require('crypto');
const { call, resetEnv } = require('./helpers');
const { _cache } = require('../lib/news');

const SB = 'https://proj.supabase.co';
let profiles, aiCalls, stripeCalls;
const rssBody = `<rss><channel><item><title>Infosys raises FY27 revenue guidance, announces buyback</title><link>https://n.com/1</link><pubDate>${new Date().toUTCString()}</pubDate></item><item><title>TCS shares fall 3% after weak deal wins</title><link>https://n.com/2</link><pubDate>${new Date().toUTCString()}</pubDate></item></channel></rss>`;

function fakeFetch() {
  return async (url, opts = {}) => {
    const method = opts.method || 'GET';
    const json = (status, d) => ({ ok: status < 400, status, json: async () => d, text: async () => JSON.stringify(d) });
    if (url === SB + '/auth/v1/user') {
      const tok = (opts.headers.Authorization || '').replace('Bearer ', '');
      const users = { 'tok-free': { id: 'u-free', email: 'free@x.com' }, 'tok-pro': { id: 'u-pro', email: 'pro@x.com' }, 'tok-new': { id: 'u-new', email: 'new@x.com' } };
      return users[tok] ? json(200, users[tok]) : json(401, { msg: 'bad jwt' });
    }
    if (url.startsWith(SB + '/rest/v1/profiles')) {
      const q = new URL(url).searchParams;
      const filt = [...q.entries()].find(([k, v]) => v.startsWith('eq.'));
      const match = p => !filt || String(p[filt[0]]) === decodeURIComponent(filt[1].slice(3));
      if (method === 'GET') return json(200, profiles.filter(match));
      if (method === 'POST') { const b = JSON.parse(opts.body); if (!profiles.find(p => p.id === b.id)) profiles.push({ plan: 'free', watchlist: [], ...b }); return json(201, profiles.filter(p => p.id === b.id)); }
      if (method === 'PATCH') { const b = JSON.parse(opts.body); const rows = profiles.filter(match); rows.forEach(p => Object.assign(p, b)); return json(200, rows); }
    }
    if (url.startsWith('https://api.anthropic.com/')) {
      aiCalls++;
      const prompt = JSON.parse(opts.body).messages[0].content;
      const text = prompt.includes('JSON array') ? '[{"id":"h1","score":0.8,"tickers":["INFY"],"sector":"IT","impact":"high","horizon":"short-term","reason":"Guidance raised."}]' : 'Market bias: Mildly bullish.';
      return json(200, { content: [{ type: 'text', text }] });
    }
    if (url.startsWith('https://api.stripe.com/')) { stripeCalls.push({ url, body: opts.body }); return json(200, { url: 'https://checkout.stripe.com/c/sess_1' }); }
    return { ok: true, status: 200, text: async () => rssBody, json: async () => ({}) };
  };
}
function setup({ auth = false, ai = false, pay = false } = {}) {
  resetEnv(); _cache.clear();
  profiles = [{ id: 'u-free', email: 'free@x.com', plan: 'free', watchlist: [] }, { id: 'u-pro', email: 'pro@x.com', plan: 'pro', watchlist: ['INFY'], stripe_customer_id: 'cus_pro' }];
  aiCalls = 0; stripeCalls = [];
  global.fetch = fakeFetch();
  if (auth) Object.assign(process.env, { SUPABASE_URL: SB, SUPABASE_ANON_KEY: 'anon', SUPABASE_SERVICE_ROLE_KEY: 'service' });
  if (ai) process.env.ANTHROPIC_API_KEY = 'sk-ant-test';
  if (pay) Object.assign(process.env, { STRIPE_SECRET_KEY: 'sk_test', STRIPE_PRICE_ID: 'price_1', STRIPE_WEBHOOK_SECRET: 'whsec_x' });
}
const H = tok => ({ authorization: 'Bearer ' + tok });
const api = name => require('../api/' + name);

test('demo mode: news works, config shows features off, protected routes explain themselves', async () => {
  setup();
  const n = await call(api('news'), { url: '/api/news?market=IN' });
  assert.strictEqual(n.statusCode, 200);
  const d = n.json();
  assert.ok(d.items.length >= 2); assert.ok(d.summary.mood >= 0);
  assert.match(n.getHeader('cache-control'), /s-maxage/);
  const c = (await call(api('config'))).json();
  assert.deepStrictEqual(c.features, { auth: false, payments: false, ai: false, api: false });
  assert.strictEqual(c.supabase, null);
  assert.strictEqual((await call(api('me'))).statusCode, 503);
  assert.strictEqual((await call(api('ai'), { method: 'POST', body: { mode: 'score', headlines: [{ id: 'a', text: 'Infosys raises guidance' }] } })).json().error.code, 'ai_not_configured');
  assert.strictEqual((await call(api('news'), { method: 'POST' })).statusCode, 405);
});

test('demo mode with AI key: AI works without sign-in, with a per-IP cap', async () => {
  setup({ ai: true }); process.env.DEMO_AI_DAILY = '2';
  const body = { mode: 'score', headlines: [{ id: 'abc', text: 'Infosys raises FY27 revenue guidance' }] };
  const r = await call(api('ai'), { method: 'POST', body, headers: { 'x-forwarded-for': '9.9.9.9' } });
  assert.strictEqual(r.statusCode, 200);
  assert.strictEqual(r.json().results.abc.label, 'Bullish');
  await call(api('ai'), { method: 'POST', body, headers: { 'x-forwarded-for': '9.9.9.9' } });
  const third = await call(api('ai'), { method: 'POST', body, headers: { 'x-forwarded-for': '9.9.9.9' } });
  assert.strictEqual(third.statusCode, 429);
});

test('signed-in: profile is created on first visit and /api/me reports limits', async () => {
  setup({ auth: true });
  const r = await call(api('me'), { headers: H('tok-new') });
  assert.strictEqual(r.statusCode, 200);
  assert.strictEqual(r.json().plan, 'free');
  assert.ok(profiles.find(p => p.id === 'u-new'));
  assert.strictEqual((await call(api('me'), { headers: H('nope') })).statusCode, 401);
});

test('AI quota: free users are stopped after their daily credits, and only charged on success', async () => {
  setup({ auth: true, ai: true }); process.env.FREE_AI_DAILY = '1';
  const body = { mode: 'brief', headlines: [{ id: 'a', text: 'Infosys raises FY27 revenue guidance', score: 0.6, label: 'Bullish' }], context: { market: 'IN', mood: 60, net: 0.2 } };
  assert.strictEqual((await call(api('ai'), { method: 'POST', body })).statusCode, 401, 'needs sign-in when auth is on');
  const ok = await call(api('ai'), { method: 'POST', body, headers: H('tok-free') });
  assert.strictEqual(ok.statusCode, 200); assert.match(ok.json().text, /Market bias/);
  assert.deepStrictEqual(ok.json().usage.ai, { used: 1, limit: 1 });
  const no = await call(api('ai'), { method: 'POST', body, headers: H('tok-free') });
  assert.strictEqual(no.statusCode, 402); assert.strictEqual(no.json().error.code, 'quota');
  assert.strictEqual(aiCalls, 1);
});

test('watchlist sync respects plan limits', async () => {
  setup({ auth: true });
  const ok = await call(api('watchlist'), { method: 'PUT', headers: H('tok-free'), body: { symbols: ['infy', 'TCS'] } });
  assert.deepStrictEqual(ok.json().watchlist, ['INFY', 'TCS']);
  const big = await call(api('watchlist'), { method: 'PUT', headers: H('tok-free'), body: { symbols: ['A', 'B', 'C', 'D', 'E', 'F'] } });
  assert.strictEqual(big.statusCode, 402);
});

test('API keys: Pro only, shown once, stored hashed, and usable on /api/v1/sentiment', async () => {
  setup({ auth: true });
  assert.strictEqual((await call(api('apikey'), { method: 'POST', headers: H('tok-free') })).statusCode, 402);
  const k = (await call(api('apikey'), { method: 'POST', headers: H('tok-pro') })).json().apiKey;
  assert.match(k, /^mt_[a-f0-9]{40}$/);
  const pro = profiles.find(p => p.id === 'u-pro');
  assert.strictEqual(pro.api_key_hash, crypto.createHash('sha256').update(k).digest('hex'));
  assert.ok(!JSON.stringify(profiles).includes(k), 'plain key never stored');
  const r = await call(api('v1/sentiment'), { url: '/api/v1/sentiment?symbol=INFY&limit=1', headers: { 'x-api-key': k } });
  assert.strictEqual(r.statusCode, 200);
  const d = r.json();
  assert.strictEqual(d.query.symbol, 'INFY'); assert.strictEqual(d.headlines.length, 1); assert.strictEqual(d.usage.used, 1);
  assert.strictEqual(r.getHeader('access-control-allow-origin'), '*');
  assert.strictEqual((await call(api('v1/sentiment'), { url: '/api/v1/sentiment', headers: { 'x-api-key': 'mt_' + '0'.repeat(40) } })).statusCode, 401);
  assert.strictEqual((await call(api('v1/sentiment'), { url: '/api/v1/sentiment' })).statusCode, 401);
  pro.plan = 'free';
  assert.strictEqual((await call(api('v1/sentiment'), { url: '/api/v1/sentiment', headers: { 'x-api-key': k } })).statusCode, 402);
});

test('Stripe: checkout for free users, webhook upgrades and downgrades', async () => {
  setup({ auth: true, pay: true }); process.env.SITE_URL = 'https://moodtape.test';
  const co = await call(api('stripe/checkout'), { method: 'POST', headers: H('tok-free') });
  assert.strictEqual(co.json().url, 'https://checkout.stripe.com/c/sess_1');
  const sent = decodeURIComponent(stripeCalls[0].body);
  assert.ok(sent.includes('client_reference_id=u-free') && sent.includes('success_url=https://moodtape.test/app?upgraded=1'));
  assert.strictEqual((await call(api('stripe/checkout'), { method: 'POST', headers: H('tok-pro') })).statusCode, 409);

  const hook = async event => { const b = JSON.stringify(event), t = Math.floor(Date.now() / 1000); const sig = crypto.createHmac('sha256', 'whsec_x').update(`${t}.${b}`).digest('hex'); return call(api('stripe/webhook'), { method: 'POST', body: b, headers: { 'stripe-signature': `t=${t},v1=${sig}` } }); };
  assert.strictEqual((await hook({ id: 'evt1', type: 'checkout.session.completed', data: { object: { mode: 'subscription', client_reference_id: 'u-free', customer: 'cus_new', subscription: 'sub_new' } } })).statusCode, 200);
  const u = profiles.find(p => p.id === 'u-free');
  assert.strictEqual(u.plan, 'pro'); assert.strictEqual(u.stripe_customer_id, 'cus_new');
  await hook({ id: 'evt2', type: 'customer.subscription.deleted', data: { object: { id: 'sub_new', customer: 'cus_new', status: 'canceled', metadata: {} } } });
  assert.strictEqual(u.plan, 'free');
  const bad = await call(api('stripe/webhook'), { method: 'POST', body: '{}', headers: { 'stripe-signature': 't=1,v1=00' } });
  assert.strictEqual(bad.statusCode, 400);
});

test('billing portal needs a Stripe customer', async () => {
  setup({ auth: true, pay: true });
  assert.strictEqual((await call(api('stripe/portal'), { method: 'POST', headers: H('tok-free') })).statusCode, 404);
  assert.strictEqual((await call(api('stripe/portal'), { method: 'POST', headers: H('tok-pro') })).statusCode, 200);
});
