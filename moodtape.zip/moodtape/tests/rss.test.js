'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { parseFeed, splitPublisher } = require('../lib/rss');

const RSS = `<?xml version="1.0"?><rss><channel><title>Feed</title>
<item><title><![CDATA[Infosys raises guidance &amp; announces buyback]]></title><link>https://ex.com/a</link><pubDate>Wed, 07 Oct 2026 05:00:00 GMT</pubDate></item>
<item><title>Tata Steel &#8216;rallies&#8217; 4%</title><link><![CDATA[https://ex.com/b]]></link><pubDate>not a date</pubDate><source url="https://pub.com">Pub Daily</source></item>
<item><title></title><link>https://ex.com/c</link></item>
</channel></rss>`;
const ATOM = `<feed><entry><title type="html">Nvidia soars &lt;b&gt;7%&lt;/b&gt;</title><link rel="alternate" href="https://ex.com/n"/><updated>2026-10-07T04:00:00Z</updated></entry></feed>`;

test('parses RSS items with CDATA, entities and sources', () => {
  const r = parseFeed(RSS, 'Fallback');
  assert.strictEqual(r.length, 2);
  assert.strictEqual(r[0].title, 'Infosys raises guidance & announces buyback');
  assert.strictEqual(r[0].time, Date.parse('Wed, 07 Oct 2026 05:00:00 GMT'));
  assert.strictEqual(r[0].source, 'Fallback');
  assert.strictEqual(r[1].title, 'Tata Steel ‘rallies’ 4%');
  assert.strictEqual(r[1].link, 'https://ex.com/b');
  assert.strictEqual(r[1].time, null);
  assert.strictEqual(r[1].source, 'Pub Daily');
});
test('parses Atom entries and strips markup', () => {
  const r = parseFeed(ATOM, 'A');
  assert.strictEqual(r[0].title, 'Nvidia soars 7%');
  assert.strictEqual(r[0].link, 'https://ex.com/n');
});
test('rejects garbage input', () => { assert.deepStrictEqual(parseFeed(null), []); assert.deepStrictEqual(parseFeed('<html></html>'), []); });
test('splits the Google News publisher suffix', () => {
  assert.deepStrictEqual(splitPublisher('Sensex jumps 500 points - The Economic Times', 'Google News'), { title: 'Sensex jumps 500 points', source: 'The Economic Times' });
  assert.deepStrictEqual(splitPublisher('Bajaj-Auto sales rise', 'Mint'), { title: 'Bajaj-Auto sales rise', source: 'Mint' });
});
