'use strict';
const test = require('node:test');
const assert = require('node:assert');
const crypto = require('crypto');
const { verifySignature, planChange, form } = require('../lib/stripe');

const secret = 'whsec_test';
const sign = (body, t) => `t=${t},v1=${crypto.createHmac('sha256', secret).update(`${t}.${body}`).digest('hex')}`;
test('accepts a valid signature', () => { const b = '{"a":1}'; assert.ok(verifySignature(Buffer.from(b), sign(b, 1000), secret, 300, 1100)); });
test('rejects a tampered body, wrong secret, or old timestamp', () => {
  const b = '{"a":1}', h = sign(b, 1000);
  assert.strictEqual(verifySignature('{"a":2}', h, secret, 300, 1100), false);
  assert.strictEqual(verifySignature(b, h, 'whsec_other', 300, 1100), false);
  assert.strictEqual(verifySignature(b, h, secret, 300, 2000), false);
  assert.strictEqual(verifySignature(b, '', secret), false);
});
test('maps checkout completion to Pro', () => {
  const c = planChange({ type: 'checkout.session.completed', data: { object: { mode: 'subscription', client_reference_id: 'u1', customer: 'cus_1', subscription: 'sub_1' } } });
  assert.deepStrictEqual(c, { match: { id: 'u1' }, patch: { plan: 'pro', stripe_customer_id: 'cus_1', stripe_subscription_id: 'sub_1' } });
});
test('maps subscription status changes', () => {
  const up = s => planChange({ type: 'customer.subscription.updated', data: { object: { id: 'sub_1', customer: 'cus_1', status: s, metadata: {} } } }).patch.plan;
  assert.strictEqual(up('active'), 'pro'); assert.strictEqual(up('past_due'), 'pro'); assert.strictEqual(up('canceled'), 'free'); assert.strictEqual(up('unpaid'), 'free');
  assert.strictEqual(planChange({ type: 'customer.subscription.deleted', data: { object: { id: 'sub_1', customer: 'cus_1', status: 'active' } } }).patch.plan, 'free');
  assert.strictEqual(planChange({ type: 'invoice.paid', data: { object: {} } }), null);
});
test('form-encodes nested params the way Stripe expects', () => {
  assert.strictEqual(decodeURIComponent(form({ line_items: { 0: { price: 'p', quantity: 1 } }, x: undefined }).toString()), 'line_items[0][price]=p&line_items[0][quantity]=1');
});
