'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { getNews, _cache } = require('../lib/news');

const now = Date.parse('2026-10-07T06:00:00Z');
const rss = items => `<rss><channel>${items.map(([t, l, d]) => `<item><title>${t}</title><link>${l}</link><pubDate>${new Date(d).toUTCString()}</pubDate></item>`).join('')}</channel></rss>`;
function fakeFetch(map) {
  return async url => {
    for (const [k, v] of Object.entries(map)) if (url.includes(k)) { if (v instanceof Error) throw v; return { ok: true, status: 200, text: async () => v }; }
    return { ok: false, status: 404, text: async () => '' };
  };
}

test('collects, de-duplicates, filters old news and scores', async () => {
  _cache.clear();
  const f = fakeFetch({
    'economictimes.indiatimes.com/markets/rssfeeds': rss([
      ['Infosys raises FY27 revenue guidance, announces buyback', 'https://et.com/1', now - 3600e3],
      ['TCS shares fall 3% after weak deal wins', 'https://et.com/2', now - 7200e3],
      ['Very old news about Reliance Industries profit', 'https://et.com/3', now - 5 * 864e5]
    ]),
    'moneycontrol.com/rss/marketreports': rss([['Infosys raises FY27 revenue guidance, announces buyback!', 'https://mc.com/1', now - 1800e3]]),
    'livemint': new Error('timeout')
  });
  const d = await getNews({ market: 'IN' }, { fetchImpl: f, now, noCache: true });
  assert.strictEqual(d.items.length, 2, 'duplicate and old item removed');
  assert.strictEqual(d.items[0].syms[0], 'INFY');
  assert.strictEqual(d.items[0].lex.label, 'Bullish');
  assert.strictEqual(d.items[1].lex.label, 'Bearish');
  assert.ok(d.items.every(i => i.mkt === 'IN' && i.id.length === 12));
  const mint = d.sources.find(s => s.name === 'Mint Markets');
  assert.strictEqual(mint.ok, false);
});
test('caches results per query', async () => {
  _cache.clear();
  let calls = 0;
  const f = async () => { calls++; return { ok: true, status: 200, text: async () => rss([['Nvidia shares soar 7% on record revenue', 'https://x.com/1', now]]) }; };
  await getNews({ market: 'US' }, { fetchImpl: f, now });
  const n = calls;
  const again = await getNews({ market: 'US' }, { fetchImpl: f, now: now + 1000 });
  assert.strictEqual(calls, n);
  assert.strictEqual(again.cached, true);
});
test('symbol search uses a stock-specific feed and keeps a 7 day window', async () => {
  _cache.clear();
  const seen = [];
  const f = async url => { seen.push(url); return { ok: true, status: 200, text: async () => rss([['Reliance Industries shares climb on Jio tariff hike - Mint', 'https://x.com/r', now - 3 * 864e5]]) }; };
  const d = await getNews({ symbol: 'reliance' }, { fetchImpl: f, now, noCache: true });
  assert.ok(seen[0].includes(encodeURIComponent('"Reliance Industries"')));
  assert.strictEqual(d.items.length, 1);
  assert.strictEqual(d.items[0].source, 'Mint');
});
