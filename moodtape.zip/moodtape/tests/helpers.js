'use strict';
const { Readable } = require('stream');
// Fake Node req/res for calling API handlers directly.
function req({ method = 'GET', url = '/', headers = {}, body } = {}) {
  const data = body === undefined ? '' : typeof body === 'string' ? body : JSON.stringify(body);
  const r = Readable.from(data ? [Buffer.from(data)] : []);
  r.method = method; r.url = url; r.headers = { host: 'localhost:3000', ...headers }; r.socket = { remoteAddress: '127.0.0.1' };
  return r;
}
function res() {
  const h = {};
  const r = { statusCode: 200, headersSent: false, body: '', setHeader: (k, v) => { h[k.toLowerCase()] = v; }, getHeader: k => h[k.toLowerCase()], headers: h };
  r.end = b => { r.body = b ? String(b) : ''; r.headersSent = true; r.done && r.done(); };
  r.json = () => JSON.parse(r.body || '{}');
  return r;
}
async function call(handler, opts) { const q = req(opts), s = res(); await handler(q, s); return s; }
const ENV_KEYS = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY', 'STRIPE_SECRET_KEY', 'STRIPE_PRICE_ID', 'STRIPE_WEBHOOK_SECRET', 'ANTHROPIC_API_KEY', 'OPENAI_API_KEY', 'AI_PROVIDER', 'FREE_AI_DAILY', 'DEMO_AI_DAILY', 'SITE_URL'];
function resetEnv() { for (const k of ENV_KEYS) delete process.env[k]; }
module.exports = { req, res, call, resetEnv };
