'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { consume, usage, cleanWatchlist, planOf } = require('../lib/plans');

const day = Date.parse('2026-10-07T10:00:00Z');
test('free plan AI quota is enforced and resets daily', () => {
  let p = { plan: 'free' };
  for (let i = 0; i < 3; i++) { const r = consume(p, 'ai', 1, day); assert.ok(r.ok); p = { ...p, ...r.patch }; }
  assert.strictEqual(consume(p, 'ai', 1, day).ok, false);
  assert.ok(consume(p, 'ai', 1, day + 864e5).ok, 'new UTC day resets the counter');
  assert.deepStrictEqual(usage(p, day).ai, { used: 3, limit: 3 });
});
test('free plan has no API quota, pro does', () => {
  assert.strictEqual(consume({ plan: 'free' }, 'api', 1, day).ok, false);
  assert.ok(consume({ plan: 'pro' }, 'api', 1, day).ok);
});
test('unknown plans are treated as free', () => { assert.strictEqual(planOf({ plan: 'gold' }), 'free'); assert.strictEqual(planOf(null), 'free'); });
test('watchlist is cleaned and capped by plan', () => {
  assert.deepStrictEqual(cleanWatchlist(['infy', 'INFY', ' tcs ', 'bad symbol!'], { plan: 'free' }).symbols, ['INFY', 'TCS']);
  const r = cleanWatchlist(['A', 'B', 'C', 'D', 'E', 'F'], { plan: 'free' });
  assert.strictEqual(r.ok, false); assert.strictEqual(r.max, 5);
  assert.ok(cleanWatchlist(['A', 'B', 'C', 'D', 'E', 'F'], { plan: 'pro' }).ok);
  assert.strictEqual(cleanWatchlist('INFY', {}).ok, false);
});
