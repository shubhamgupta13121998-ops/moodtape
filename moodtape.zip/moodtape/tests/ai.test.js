'use strict';
const test = require('node:test');
const assert = require('node:assert');
const ai = require('../lib/ai');

const hs = [{ id: 'abc', text: 'Infosys raises guidance' }, { id: 'def', text: 'TCS shares fall' }];
test('parses a fenced JSON reply and maps ids back', () => {
  const reply = 'Here you go:\n```json\n[{"id":"h1","score":0.7,"tickers":["infy"],"sector":"IT","impact":"high","horizon":"short-term","reason":"Guidance raised."},{"id":"h2","score":-3,"tickers":["TCS","bad ticker"],"sector":"Space","impact":"huge","horizon":"forever"}]\n```';
  const r = ai.parseScoring(reply, hs);
  assert.deepStrictEqual(Object.keys(r), ['abc', 'def']);
  assert.strictEqual(r.abc.label, 'Bullish'); assert.deepStrictEqual(r.abc.tickers, ['INFY']);
  assert.strictEqual(r.def.score, -1, 'score clamped');
  assert.strictEqual(r.def.label, 'Bearish');
  assert.deepStrictEqual(r.def.tickers, ['TCS']);
  assert.strictEqual(r.def.sector, ''); assert.strictEqual(r.def.impact, 'medium'); assert.strictEqual(r.def.horizon, 'short-term');
});
test('ignores unknown ids and non-numeric scores', () => {
  const r = ai.parseScoring('[{"id":"h9","score":1},{"id":"h1","score":"high"}]', hs);
  assert.deepStrictEqual(r, {});
});
test('throws a clean error on unreadable replies', () => { assert.throws(() => ai.parseScoring('sorry, I cannot', hs), /could not be read/); });
test('cleans headline input from the browser', () => {
  const c = ai.cleanHeadlines([{ id: 1, text: '  Infosys   raises guidance today  ', syms: ['INFY', '<script>'] }, { text: 'short' }, null]);
  assert.strictEqual(c.length, 1); assert.strictEqual(c[0].text, 'Infosys raises guidance today'); assert.deepStrictEqual(c[0].syms, ['INFY']);
  assert.throws(() => ai.cleanHeadlines('x'));
});
test('scoring prompt numbers headlines h1..hN', () => { const p = ai.scoringPrompt(hs); assert.ok(p.includes('h1: Infosys raises guidance') && p.includes('h2: TCS shares fall')); });
