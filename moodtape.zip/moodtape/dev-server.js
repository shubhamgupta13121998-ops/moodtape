'use strict';
// Local server that behaves like Vercel: static files from /public (clean URLs) and /api/* functions.
// Run: node dev-server.js   then open http://localhost:3000
const http = require('http');
const fs = require('fs');
const path = require('path');

// Load .env if present (simple KEY=VALUE lines)
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
  const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line); if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^['"]|['"]$/g, '');
}

const PUB = path.join(__dirname, 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.json': 'application/json', '.ico': 'image/x-icon', '.txt': 'text/plain', '.xml': 'application/xml' };

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://local');
  let p = decodeURIComponent(url.pathname);
  if (p.startsWith('/api/')) {
    const file = path.join(__dirname, p.replace(/\/+$/, '') + '.js');
    if (!file.startsWith(path.join(__dirname, 'api')) || !fs.existsSync(file)) { res.statusCode = 404; return res.end('{"error":{"code":"not_found"}}'); }
    try { delete require.cache[require.resolve(file)]; return await require(file)(req, res); }
    catch (e) { console.error(e); res.statusCode = 500; return res.end('{"error":{"code":"server_error"}}'); }
  }
  if (p === '/') p = '/index.html';
  let f = path.join(PUB, p);
  if (!f.startsWith(PUB)) { res.statusCode = 403; return res.end(); }
  if (!path.extname(f) && fs.existsSync(f + '.html')) f += '.html';
  if (!fs.existsSync(f) || fs.statSync(f).isDirectory()) { f = path.join(PUB, '404.html'); res.statusCode = 404; }
  res.setHeader('Content-Type', TYPES[path.extname(f)] || 'application/octet-stream');
  fs.createReadStream(f).pipe(res);
});
const port = Number(process.env.PORT) || 3000;
server.listen(port, () => console.log(`MoodTape running at http://localhost:${port}`));
module.exports = server;
