# MoodTape

Live stock market news sentiment for Indian (NSE/BSE) and global markets, as a ready-to-launch SaaS.

MoodTape collects financial headlines every few minutes, scores each one from −1 (bearish) to +1 (bullish) with a finance-tuned engine, tags the stocks and sectors it mentions, and shows the overall market mood. AI analysis (Claude or OpenAI) adds impact, time horizon, a reason, a market brief and single-stock outlooks. Users sign in, upgrade to Pro through Stripe, and Pro users get a REST API.

![Dashboard](docs/screenshots/1-dashboard.png)

## What's included

| Area | Details |
|---|---|
| Landing page | Hero with live mood card, how it works, features, coverage, API, pricing, FAQ (`public/index.html`) |
| Dashboard | Mood gauge, headline split, top movers, ticker tape, live feed with explainable scores, stock search, watchlist, sector heatmap, hourly chart, CSV export, paste/upload your own headlines (`public/app.html`) |
| Sentiment engine | 170+ finance phrases, negation ("fails to beat"), intensity, concession ("despite"), % magnitude; 80+ tickers, indices and themes; shared by browser and server (`public/js/engine.js`) |
| Live news | RSS from Indian and US financial sources, optional Marketaux / Finnhub APIs, de-duplication, caching (`lib/news.js`, `lib/feeds.js`) |
| AI | Headline re-scoring, market brief, stock outlook. Anthropic or OpenAI, chosen by env (`lib/ai.js`) |
| Accounts | Email magic link and Google sign-in via Supabase, synced watchlist (`lib/supabase.js`, `lib/auth.js`) |
| Billing | Stripe Checkout, billing portal, signed webhooks; Free and Pro plans with daily limits (`lib/stripe.js`, `lib/plans.js`) |
| Public API | `GET /api/v1/sentiment` with hashed API keys and daily quotas, docs page at `/docs` |
| Legal | Terms, privacy, disclaimer and refund templates at `/legal` |
| Tests | 48 automated tests: engine, feed parsing, plans, Stripe signatures and plan changes, AI parsing, and end-to-end API flows |

Zero npm dependencies. Plain Node.js 18+ and static HTML/CSS/JS. Nothing to build.

## Run it locally

```bash
node dev-server.js        # http://localhost:3000
npm test                  # runs all tests
```

With no settings, the site runs in demo mode: live news and instant scoring work; sign-in, AI and payments stay hidden.

## Deploy (Vercel, free tier)

1. Push this folder to a GitHub repository.
2. In Vercel, **Add New → Project**, import the repository, keep the defaults, **Deploy**.
3. Open `https://YOUR-SITE/api/health` to see which news sources answered and which features are on.

Then switch features on by adding environment variables in **Vercel → Settings → Environment Variables** (full list in `.env.example`) and redeploying.

### AI
Set `ANTHROPIC_API_KEY` (default model `claude-haiku-4-5-20251001`) or `AI_PROVIDER=openai` with `OPENAI_API_KEY`. Check the model name you want against your provider's current model list and set `ANTHROPIC_MODEL` / `OPENAI_MODEL`.

### Sign-in (Supabase)
1. Create a project at supabase.com.
2. **SQL Editor → New query**, paste `supabase/schema.sql`, **Run**.
3. **Authentication → URL Configuration**: Site URL = your domain; add `https://YOUR-SITE/app` to Redirect URLs.
4. Optional: **Authentication → Providers → Google**, then set `SUPABASE_GOOGLE_ENABLED=true`.
5. Copy `SUPABASE_URL`, `SUPABASE_ANON_KEY` and `SUPABASE_SERVICE_ROLE_KEY` from **Project Settings → API** into Vercel.

### Payments (Stripe)
1. Create a product "MoodTape Pro" with a recurring price; copy the price ID to `STRIPE_PRICE_ID`.
2. Copy the secret key to `STRIPE_SECRET_KEY`.
3. **Developers → Webhooks → Add endpoint**: `https://YOUR-SITE/api/stripe/webhook`, events `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`. Copy the signing secret to `STRIPE_WEBHOOK_SECRET`.
4. Turn on the customer portal in **Settings → Billing → Customer portal**.
5. Set `SITE_URL` and `PRO_PRICE_LABEL` (e.g. `$9 / month`).

## Project layout

```
api/            Vercel serverless functions (one file = one route)
  news.js         GET live scored headlines (+ summary)
  health.js       GET feature and news-source status
  config.js       GET public config for the browser
  me.js           GET signed-in user's plan, usage, watchlist
  watchlist.js    PUT watchlist
  apikey.js       POST/DELETE API key
  ai.js           POST AI score / brief / outlook
  v1/sentiment.js GET public REST API
  stripe/         checkout, portal, webhook
lib/            shared server code (no dependencies)
public/         static site: landing, dashboard, docs, legal, engine
supabase/       database schema
tests/          node:test suites
docs/           handover, sale listing, Hindi guide, screenshots
```

## News sources and licensing

Default sources are public RSS feeds listed in `lib/feeds.js`. MoodTape stores and shows headlines and links only, never article text. Publishers' terms for commercial reuse of feeds vary, so review them before charging customers, or set `MARKETAUX_API_KEY` / `FINNHUB_API_KEY` to use a licensed news API. Feed addresses change over time; `/api/health` shows which ones are answering.

## Not investment advice

MoodTape measures how news reads. Keep the disclaimer on every page. In India, giving buy/sell recommendations requires SEBI registration; the product is positioned as an information tool and does not make recommendations.
