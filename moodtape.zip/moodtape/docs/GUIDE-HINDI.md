# MoodTape: aapke liye seedhi guide (Hinglish)

## Ye kya hai?
MoodTape ek poora SaaS product hai: website + dashboard + login + payment + API. Isko aap kisi buyer ko bech sakte ho. Buyer ise apne naam par chalayega aur customers se monthly paisa lega.

## Bechne se pehle 3 kaam (zaroori)

### 1. Live demo link banao (sabse important)
Buyer bina demo dekhe kharidta nahi. Demo free me ban jata hai:

1. **github.com** par free account banao.
2. **New repository** banao, naam `moodtape`, **Private** rakho.
3. Zip ko extract karo aur saari files repository me upload karo ("Add file → Upload files", folders ke saath drag karo).
   - Tablet par folder upload mushkil hota hai. Agar na ho paaye, kisi laptop/cyber cafe se 10 minute ka kaam hai.
4. **vercel.com** par GitHub se login karo → **Add New → Project** → `moodtape` chuno → **Deploy**.
5. 1–2 minute me link mil jayega, jaise `moodtape-xyz.vercel.app`.
6. Link ke aage `/api/health` lagakar kholo. `"ok": true` dikhe to live news chal rahi hai.

Bina kisi key ke bhi demo chalega: live news + sentiment score. Login, AI aur payment tab tak chhupe rahenge. Buyer ke liye itna kaafi hai.

### 2. Screenshots
`docs/screenshots/` folder me 5 screenshots taiyaar hain. Listing me yahi lagao.

### 3. Listing post karo
`docs/SALE-LISTING.md` me poori listing likhi hui hai. `[ ]` wali jagah bharo (price, demo link) aur copy karke post karo.

**Kahan bechein:** Flippa, Acquire.com, SideProjectors. Saath me LinkedIn/Twitter par short version post karo, aur trading educators, Telegram channel owners, chhote brokers ko seedha email karo. Seedhe buyer aksar zyada paisa dete hain.

## Price kitna rakhein?
Bina users aur revenue ke code-only products aam taur par kam daam par bikte hain, aksar kuch sau se kuch hazaar dollar tak. Price badhane ke 2 sabse asardaar tareeke:
- Kuch real users lao (free plan par bhi chalega). "50 users" likhna listing ko kaafi mazboot bana deta hai.
- Seedha strategic buyer dhoondo (broker, trading course wale, fintech app), jinke liye ye unke business me fit hota ho.

## Agar aap khud AI, login aur payment chalu karna chahein (optional)
Ye buyer bhi kar sakta hai. Aapko karna ho to:

| Feature | Kya chahiye | Kahan daalna hai |
|---|---|---|
| AI analysis | Anthropic (console.anthropic.com) ya OpenAI ki API key | Vercel → Settings → Environment Variables → `ANTHROPIC_API_KEY` |
| Login | supabase.com par free project, `supabase/schema.sql` chalao | `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` |
| Payment | Stripe account, ek monthly price, ek webhook | `STRIPE_SECRET_KEY`, `STRIPE_PRICE_ID`, `STRIPE_WEBHOOK_SECRET` |

Har key daalne ke baad Vercel me **Redeploy** dabao. Poore steps `README.md` me English me hain.

## Sach batana zaroori hai
Listing me ye saaf likha hai, aur ise mat hatao:
- Abhi koi revenue ya users nahi hain.
- Product AI ki madad se banaya gaya hai.
- Live news, payment aur login ka final test buyer ke deployment par hona baaki hai.

Chhupane se deal baad me toot sakti hai, aur marketplaces aajkal ye cheezein poochte hain.

## Sale ke time
- Payment hamesha marketplace ke **escrow** se lo.
- Ek simple **Asset Purchase Agreement** banao (code, naam, domain sab buyer ko).
- `docs/HANDOVER.md` checklist buyer ke saath tick karo.
- Naam "MoodTape" kisi aur ka trademark to nahi, ye ek baar check kar lo.
