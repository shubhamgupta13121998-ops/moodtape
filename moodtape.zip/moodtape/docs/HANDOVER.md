# Buyer handover checklist

Use this list during the sale. Tick each item with the buyer.

## 1. What is being transferred
- [ ] Full source code (this folder), all rights included
- [ ] Brand name "MoodTape", logo (`public/favicon.svg`), screenshots and copy
- [ ] Domain name (if one was bought) and its DNS
- [ ] Vercel project (transfer to the buyer's team, or the buyer redeploys from the repo)
- [ ] GitHub repository (transfer ownership)
- [ ] Supabase project (transfer org ownership) or a fresh project with `supabase/schema.sql`
- [ ] Stripe: the buyer uses their own Stripe account. Update `STRIPE_*` env variables and recreate the webhook.
- [ ] AI keys: the buyer uses their own Anthropic or OpenAI key.

## 2. Facts to state honestly
- Pre-revenue: no paying customers, no traffic history.
- Built with AI assistance (Claude) and reviewed with 48 automated tests.
- Tested locally with simulated Supabase, Stripe, AI and news responses. Live news feeds, live Stripe payments and live sign-in still need a check on the buyer's own deployment (`/api/health` shows the feed status).
- Default news comes from public RSS feeds. For commercial use, review each publisher's terms or switch to a licensed API (Marketaux / Finnhub supported).
- The legal pages are templates with `[PLACEHOLDERS]`. Have a lawyer review them for the buyer's country.

## 3. After transfer (buyer)
- [ ] Rotate every secret: Supabase service-role key, Stripe keys and webhook secret, AI key
- [ ] Set `SITE_URL`, `SUPPORT_EMAIL`, `SITE_NAME`
- [ ] Fill the placeholders in `public/legal.html`
- [ ] Check the trademark status of the name in the target markets
- [ ] Run `npm test` and open `/api/health` after the first deploy
- [ ] Make one test purchase in Stripe test mode, then switch to live keys

## 4. Running costs (approximate, check current pricing)
- Vercel Hobby: free for personal/non-commercial use; a commercial launch needs Vercel Pro.
- Supabase: free tier to start.
- Stripe: per-transaction fees only.
- AI: pay per use. Headline scoring on a small model costs a fraction of a cent per request; plan limits cap the spend per user.
- Optional news API: Marketaux and Finnhub have free tiers and paid plans.

## 5. Growth ideas for the buyer
- Email or Telegram alerts when a watchlist stock turns strongly bearish or bullish
- Historical sentiment storage and charts (add a `headlines` table)
- Razorpay for Indian UPI payments alongside Stripe
- Hindi and regional-language headline support
- Broker integrations (Zerodha Kite, Upstox) to overlay sentiment on positions
- A WordPress / website widget showing the live mood gauge
