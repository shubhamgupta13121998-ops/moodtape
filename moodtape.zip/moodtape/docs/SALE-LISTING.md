# Marketplace listing: MoodTape

Copy the parts you need into Flippa, Acquire.com, SideProjectors, MicroAcquire-style marketplaces, or a direct email to buyers. Replace `[ ]` items before posting.

---

## Title
MoodTape: live stock market news sentiment SaaS (India + US), AI analysis, Stripe billing and REST API

## One-line pitch
A ready-to-launch fintech SaaS that turns live financial headlines into a market mood score, stock and sector sentiment, and AI briefs, with Free/Pro plans and a paid API already built.

## Description
MoodTape reads financial news every few minutes and scores each headline from −1 (bearish) to +1 (bullish). Traders open it to see the market's mood before the open: which stocks the news is turning on, which sectors are under pressure, and whether sentiment is improving or worsening through the day.

It is built for the Indian market (NSE, BSE, Nifty, Bank Nifty, RBI, rupee) and covers US stocks and indices too, a combination most sentiment tools skip.

**Product**
- Market mood gauge (Extreme fear → Extreme greed) with trend
- Live headline feed with explainable scores: every score shows the words that drove it, including negations like "fails to beat"
- Automatic tagging of 80+ stocks, indices and themes, plus look-up of any stock by name or symbol
- Top bullish/bearish movers, ticker tape, sector heatmap, hourly sentiment chart
- AI deep analysis: impact, time horizon and reason per headline; one-click market brief; single-stock outlook (Claude or OpenAI)
- Watchlist synced to the account, CSV export, paste/upload your own headlines
- REST API (`/api/v1/sentiment`) with hashed API keys and daily quotas, plus a docs page
- Landing page with pricing and FAQ, legal page templates, dark mode, mobile layout

**Business model already wired in**
- Free plan: live sentiment, 5-stock watchlist, 3 AI credits/day
- Pro plan ([price, default $9/month]): 100 AI credits/day, 100-stock watchlist, CSV export, API with 1,000 calls/day
- Stripe Checkout, billing portal and signed webhooks keep plans in sync. All limits are environment variables.

**Tech**
- Plain Node.js 18+ serverless functions and static HTML/CSS/JS. Zero npm dependencies, nothing to build.
- Deploys to Vercel in minutes. Supabase for sign-in (email link + Google) and the database. Stripe for payments.
- Works in demo mode with no keys at all, so a buyer can see it running immediately.
- 48 automated tests cover the sentiment engine, feed parsing, plan limits, Stripe signature checks and plan changes, AI reply parsing, and end-to-end API flows.
- Strict security headers (CSP), API keys stored as SHA-256 hashes, secrets only on the server.

## Why buy
- Skip 4–6 weeks of building: product, billing, auth, API and marketing site are done.
- Fintech and trading tools sell well to retail traders, especially in India's fast-growing trader base.
- Multiple revenue paths: subscriptions, API plans, white-label for brokers, educators or Telegram channels.
- Low running cost: free tiers cover launch; AI spend is capped by plan limits.

## Honest disclosures
- Pre-revenue: no users or revenue yet.
- Built with AI assistance and reviewed with automated tests.
- Tested locally with simulated services. Live feeds, payments and sign-in need a final check on the buyer's own deployment (a built-in `/api/health` page shows status).
- Default news uses public RSS feeds; for commercial scale, review publisher terms or switch to the supported licensed APIs (Marketaux, Finnhub).
- Legal pages are templates to be reviewed by the buyer's lawyer.
- Information tool only: it does not give buy/sell recommendations.

## What's included
Source code and all rights, brand name and logo, landing page copy, screenshots, setup guide, buyer handover checklist, [domain if any], [30 days of email support for setup questions].

## Asking price
[Your price]. Open to reasonable offers. Payment through the marketplace's escrow.

## Screenshots to upload
`docs/screenshots/1-dashboard.png`, `2-dashboard-dark.png`, `3-mobile.png`, `4-landing.png`, `5-api-docs.png`

## Demo
[Live demo link after you deploy to Vercel]

---

## Short version (for social posts or buyer emails)
Selling MoodTape, a ready-to-launch stock market news sentiment SaaS for Indian and US markets. Live mood gauge, stock and sector sentiment, AI briefs, Free/Pro plans with Stripe, and a paid REST API. Zero dependencies, deploys to Vercel in minutes, 48 automated tests. Pre-revenue, full code and brand included. Demo: [link]. Price: [price].
