-- MoodTape database schema. Run once in Supabase → SQL Editor → New query → Run.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  plan text not null default 'free' check (plan in ('free', 'pro')),
  stripe_customer_id text unique,
  stripe_subscription_id text,
  watchlist text[] not null default '{}',
  api_key_hash text unique,
  api_key_hint text,
  ai_used integer not null default 0,
  ai_day date,
  api_used integer not null default 0,
  api_day date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Only the server (service-role key) reads and writes profiles. Browsers never query this table directly.
alter table public.profiles enable row level security;

create index if not exists profiles_stripe_customer_idx on public.profiles (stripe_customer_id);
create index if not exists profiles_api_key_idx on public.profiles (api_key_hash);
