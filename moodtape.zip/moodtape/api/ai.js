'use strict';
const { handler, methods, send, readJson, fail, clientIp } = require('../lib/http');
const { features, int } = require('../lib/config');
const { requireUser } = require('../lib/auth');
const { consume, usage, planOf } = require('../lib/plans');
const ai = require('../lib/ai');
const db = require('../lib/supabase');
const E = require('../public/js/engine.js');

// Demo mode (sign-in not configured): a small per-IP daily cap, kept in memory per server instance.
const demoUse = new Map();
function demoAllow(ip, amount) {
  const day = new Date().toISOString().slice(0, 10), k = day + ip, lim = int('DEMO_AI_DAILY', 5);
  const used = demoUse.get(k) || 0;
  if (used + amount > lim) return false;
  demoUse.set(k, used + amount); if (demoUse.size > 5000) demoUse.clear();
  return true;
}

// POST /api/ai
//   { mode: "score", headlines: [{id, text, source}] }            → { results: { [id]: {score,label,tickers,sector,impact,horizon,reason} } }
//   { mode: "brief", headlines: [...scored], context: {market, mood, net} } → { text }
//   { mode: "outlook", symbol, headlines: [...scored] }              → { text }
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['POST'])) return;
  if (!features().ai) return fail(res, 503, 'ai_not_configured', 'AI analysis is not set up on this site yet.');
  const body = await readJson(req);
  const mode = ['score', 'brief', 'outlook'].includes(body.mode) ? body.mode : null;
  if (!mode) return fail(res, 400, 'bad_request', 'mode must be score, brief or outlook.');
  const headlines = ai.cleanHeadlines(body.headlines, mode === 'score' ? 25 : 60);
  if (!headlines.length) return fail(res, 400, 'bad_request', 'Send at least one headline.');
  const credits = 1; // one AI credit per request (score requests carry up to 25 headlines)

  let account = null;
  if (features().auth) {
    account = await requireUser(req);
    const q = consume(account.profile, 'ai', credits);
    if (!q.ok) return fail(res, 402, 'quota', planOf(account.profile) === 'pro' ? `You have used all ${q.limit} AI credits for today. They reset at 00:00 UTC.` : `Free plan includes ${q.limit} AI credits a day. Upgrade to Pro for more.`, { limit: q.limit, plan: planOf(account.profile) });
    account.patch = q.patch;
  } else if (!demoAllow(clientIp(req), credits)) {
    return fail(res, 429, 'demo_limit', 'Demo limit reached for today.');
  }

  let out;
  if (mode === 'score') {
    const text = await ai.complete(ai.scoringPrompt(headlines), { maxTokens: 3000 });
    out = { results: ai.parseScoring(text, headlines) };
  } else if (mode === 'brief') {
    const c = body.context || {};
    out = { text: (await ai.complete(ai.briefPrompt(headlines, { market: c.market, mood: Number(c.mood) || undefined, net: Number.isFinite(Number(c.net)) ? Number(c.net).toFixed(2) : undefined }), { maxTokens: 900, temperature: 0.4 })).trim() };
  } else {
    const sym = String(body.symbol || '').toUpperCase().replace(/[^A-Z0-9&.\-]/g, '').slice(0, 15);
    if (!sym) return fail(res, 400, 'bad_request', 'symbol is required.');
    out = { text: (await ai.complete(ai.outlookPrompt(sym, E.entity(sym).name, headlines), { maxTokens: 500, temperature: 0.4 })).trim() };
  }
  // Charge only after a successful answer
  if (account && account.patch) { const p = await db.updateProfile(account.user.id, account.patch); out.usage = usage(p || { ...account.profile, ...account.patch }); }
  send(res, 200, out);
});
