'use strict';
const { handler, methods, send } = require('../lib/http');
const { features, env } = require('../lib/config');
const { plans } = require('../lib/plans');

// GET /api/config — public settings the browser needs. Never put secret keys here.
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['GET'])) return;
  const f = features();
  send(res, 200, {
    siteName: env('SITE_NAME', 'MoodTape'),
    features: f,
    supabase: f.auth ? { url: env('SUPABASE_URL'), anonKey: env('SUPABASE_ANON_KEY'), google: env('SUPABASE_GOOGLE_ENABLED', 'false') === 'true' } : null,
    plans: plans(),
    supportEmail: env('SUPPORT_EMAIL', '')
  }, { 'Cache-Control': 'public, max-age=60' });
});
