'use strict';
const { handler, methods, send } = require('../lib/http');
const { getNews } = require('../lib/news');
const { features, aiProvider } = require('../lib/config');

// GET /api/health — which features are configured and which news sources answered. Open it after every deploy.
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['GET'])) return;
  const news = await getNews({ market: 'ALL' }, { noCache: true });
  send(res, 200, { ok: news.items.length > 0, features: features(), aiProvider: aiProvider(), headlines: news.items.length, sources: news.sources, node: process.version, time: new Date().toISOString() });
});
