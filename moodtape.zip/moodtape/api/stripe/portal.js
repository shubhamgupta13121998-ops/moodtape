'use strict';
const { handler, methods, send, fail } = require('../../lib/http');
const { features, siteUrl } = require('../../lib/config');
const { requireUser } = require('../../lib/auth');
const { portalSession } = require('../../lib/stripe');

// POST /api/stripe/portal → { url } of the Stripe billing portal (change card, cancel, invoices).
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['POST'])) return;
  if (!features().payments) return fail(res, 503, 'payments_not_configured', 'Payments are not set up on this site yet.');
  const { profile } = await requireUser(req);
  if (!profile.stripe_customer_id) return fail(res, 404, 'no_billing', 'No billing account yet. Upgrade first.');
  const s = await portalSession({ customerId: profile.stripe_customer_id, siteUrl: siteUrl(req) });
  send(res, 200, { url: s.url });
});
