'use strict';
const { handler, methods, send, fail, readRaw } = require('../../lib/http');
const { env, features } = require('../../lib/config');
const { verifySignature, planChange } = require('../../lib/stripe');
const db = require('../../lib/supabase');

// POST /api/stripe/webhook — keeps each user's plan in sync with Stripe.
// Subscribe to: checkout.session.completed, customer.subscription.created/updated/deleted
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['POST'])) return;
  if (!features().payments) return fail(res, 503, 'payments_not_configured', 'Payments are not set up.');
  const raw = await readRaw(req);
  if (!verifySignature(raw, req.headers['stripe-signature'], env('STRIPE_WEBHOOK_SECRET'))) return fail(res, 400, 'bad_signature', 'Invalid signature.');
  const event = JSON.parse(raw.toString('utf8'));
  const change = planChange(event);
  if (change) {
    let target = null;
    if (change.match.id) target = await db.getProfile(change.match.id);
    if (!target && change.match.stripe_customer_id) target = await db.findProfile('stripe_customer_id', change.match.stripe_customer_id);
    if (target) {
      const patch = { ...change.patch };
      // Ignore events for an old subscription once a newer one is on file
      if (event.type.startsWith('customer.subscription') && target.stripe_subscription_id && target.stripe_subscription_id !== patch.stripe_subscription_id && patch.plan === 'free') { /* stale */ }
      else await db.updateProfile(target.id, patch);
    } else console.warn('[stripe] no profile for event', event.type, event.id);
  }
  send(res, 200, { received: true });
});
