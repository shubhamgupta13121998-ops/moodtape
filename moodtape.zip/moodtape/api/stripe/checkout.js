'use strict';
const { handler, methods, send, fail } = require('../../lib/http');
const { features, siteUrl } = require('../../lib/config');
const { requireUser } = require('../../lib/auth');
const { planOf } = require('../../lib/plans');
const { checkoutSession } = require('../../lib/stripe');

// POST /api/stripe/checkout → { url } of a Stripe Checkout page for the Pro plan.
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['POST'])) return;
  if (!features().payments) return fail(res, 503, 'payments_not_configured', 'Payments are not set up on this site yet.');
  const { user, profile } = await requireUser(req);
  if (planOf(profile) === 'pro') return fail(res, 409, 'already_pro', 'You are already on Pro.');
  const s = await checkoutSession({ userId: user.id, email: user.email, customerId: profile.stripe_customer_id, siteUrl: siteUrl(req) });
  send(res, 200, { url: s.url });
});
