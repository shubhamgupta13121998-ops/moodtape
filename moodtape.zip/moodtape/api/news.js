'use strict';
const { handler, methods, send, query } = require('../lib/http');
const { getNews } = require('../lib/news');
const { int } = require('../lib/config');
const E = require('../public/js/engine.js');

// GET /api/news?market=IN|US|ALL&symbol=RELIANCE&q=topic
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['GET'])) return;
  const p = query(req);
  const data = await getNews({ market: (p.get('market') || 'ALL').toUpperCase(), symbol: p.get('symbol') || '', q: p.get('q') || '' });
  const ttl = int('NEWS_CACHE_SECONDS', 240);
  send(res, 200, { ...data, summary: E.summarize(data.items) }, { 'Cache-Control': `public, s-maxage=${ttl}, stale-while-revalidate=${ttl * 3}` });
});
