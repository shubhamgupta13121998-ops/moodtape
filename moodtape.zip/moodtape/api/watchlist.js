'use strict';
const { handler, methods, send, readJson, fail } = require('../lib/http');
const { requireUser } = require('../lib/auth');
const { cleanWatchlist } = require('../lib/plans');
const db = require('../lib/supabase');

// PUT /api/watchlist { symbols: ["RELIANCE", "INFY"] }
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['PUT'])) return;
  const { user, profile } = await requireUser(req);
  const body = await readJson(req);
  const r = cleanWatchlist(body.symbols, profile);
  if (!r.ok) return fail(res, r.max ? 402 : 400, r.max ? 'plan_limit' : 'bad_request', r.error, r.max ? { max: r.max } : {});
  await db.updateProfile(user.id, { watchlist: r.symbols });
  send(res, 200, { watchlist: r.symbols });
});
