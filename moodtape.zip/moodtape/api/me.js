'use strict';
const { handler, methods, send } = require('../lib/http');
const { requireUser } = require('../lib/auth');
const { planOf, limitsOf, usage } = require('../lib/plans');

// GET /api/me — the signed-in user's plan, limits, usage and watchlist.
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['GET'])) return;
  const { user, profile } = await requireUser(req);
  send(res, 200, {
    email: user.email, plan: planOf(profile), limits: limitsOf(profile), usage: usage(profile),
    watchlist: Array.isArray(profile.watchlist) ? profile.watchlist : [],
    apiKeyHint: profile.api_key_hint || null, billing: !!profile.stripe_customer_id
  });
});
