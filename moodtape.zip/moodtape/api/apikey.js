'use strict';
const crypto = require('crypto');
const { handler, methods, send, fail } = require('../lib/http');
const { requireUser } = require('../lib/auth');
const { planOf } = require('../lib/plans');
const db = require('../lib/supabase');

// POST /api/apikey → create (or replace) the user's API key. DELETE → revoke it. The full key is shown once.
module.exports = handler(async (req, res) => {
  if (!methods(req, res, ['POST', 'DELETE'])) return;
  const { user, profile } = await requireUser(req);
  if (req.method === 'DELETE') { await db.updateProfile(user.id, { api_key_hash: null, api_key_hint: null }); return send(res, 200, { revoked: true }); }
  if (planOf(profile) !== 'pro') return fail(res, 402, 'pro_required', 'API access is part of the Pro plan.');
  const key = 'mt_' + crypto.randomBytes(20).toString('hex');
  await db.updateProfile(user.id, { api_key_hash: crypto.createHash('sha256').update(key).digest('hex'), api_key_hint: key.slice(-4) });
  send(res, 200, { apiKey: key, hint: key.slice(-4) });
});
