'use strict';
const crypto = require('crypto');
const { handler, send, fail, query, bearer } = require('../../lib/http');
const { features } = require('../../lib/config');
const { getNews } = require('../../lib/news');
const { consume, planOf } = require('../../lib/plans');
const db = require('../../lib/supabase');
const E = require('../../public/js/engine.js');

const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'x-api-key, authorization', 'Access-Control-Allow-Methods': 'GET, OPTIONS' };

// GET /api/v1/sentiment?symbol=RELIANCE   or   ?market=IN|US|ALL   (header: x-api-key: mt_...)
module.exports = handler(async (req, res) => {
  for (const [k, v] of Object.entries(CORS)) res.setHeader(k, v);
  if (req.method === 'OPTIONS') { res.statusCode = 204; return res.end(); }
  if (req.method !== 'GET') return fail(res, 405, 'method_not_allowed', 'Use GET.');
  if (!features().api) return fail(res, 503, 'api_not_configured', 'The API is not enabled on this site yet.');
  const p = query(req);
  const key = String(req.headers['x-api-key'] || bearer(req) || p.get('api_key') || '');
  if (!/^mt_[a-f0-9]{40}$/.test(key)) return fail(res, 401, 'invalid_key', 'Send a valid API key in the x-api-key header.');
  const profile = await db.findProfile('api_key_hash', crypto.createHash('sha256').update(key).digest('hex'));
  if (!profile) return fail(res, 401, 'invalid_key', 'This API key is not valid. Create a new one in your account.');
  if (planOf(profile) !== 'pro') return fail(res, 402, 'pro_required', 'API access needs an active Pro plan.');
  const q = consume(profile, 'api', 1);
  if (!q.ok) return fail(res, 429, 'quota', `Daily API limit of ${q.limit} calls reached. It resets at 00:00 UTC.`);
  await db.updateProfile(profile.id, q.patch);

  const symbol = (p.get('symbol') || '').toUpperCase();
  const market = (p.get('market') || 'ALL').toUpperCase();
  const limit = Math.min(100, Math.max(1, parseInt(p.get('limit') || '30', 10) || 30));
  const data = await getNews({ market, symbol });
  const s = E.summarize(data.items);
  send(res, 200, {
    query: symbol ? { symbol, name: E.entity(symbol).name } : { market },
    mood: s.mood, mood_label: s.label, net_score: s.net, counts: s.counts, headline_count: s.count,
    tickers: s.tickers.slice(0, 25),
    headlines: data.items.slice(0, limit).map(i => ({ title: i.text, source: i.source, url: i.link, published_at: new Date(i.time).toISOString(), score: i.lex.score, label: i.lex.label, tickers: i.syms })),
    fetched_at: new Date(data.fetchedAt).toISOString(),
    usage: { used: q.used, limit: q.limit }
  }, { ...CORS, 'Cache-Control': 'no-store' });
});
