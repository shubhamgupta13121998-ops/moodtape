/*!
 * MoodTape sentiment engine — shared by the browser dashboard and the API.
 * Finance-tuned lexicon with negation, intensity, concession and % magnitude handling,
 * plus ticker / index / theme extraction for Indian (NSE/BSE) and US markets.
 * UMD: require('./engine.js') in Node, window.MoodEngine in the browser.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.MoodEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
'use strict';
// ---------- Finance sentiment lexicon ----------
const LEX = [
  // Bullish
  ['beat(s|ing)? (the )?(street |analyst |consensus )?(estimates|expectations|forecasts|views)', 2.6],
  ['top(s|ped)? (street |analyst )?(estimates|expectations|forecasts)', 2.2],
  ['(raises?|raised|hikes?|hiked|lifts?|ups) (its )?(fy ?\\d* |full[- ]year |annual )?(revenue |profit |earnings |sales )?(guidance|outlook|forecast)', 2.6],
  ['(guidance|outlook|forecast) (raised|upgraded|improves|improved)', 2.4],
  ['(all[- ]time|record|lifetime) highs?', 2.2],
  ['52[- ]week highs?', 1.6],
  ['upper circuit', 2.4],
  ['rate cuts?', 1.4],
  ['cuts? (interest |repo |policy |key )?rates?', 1.4],
  ['upgrade[sd]?', 2.0],
  ['(price )?targets? (raised|hiked|increased|upped)', 1.8],
  ['(raises?|raised|hikes?|ups) (price )?targets?', 1.8],
  ['buy ?backs?', 1.6],
  ['dividends?', 0.9],
  ['bonus (issue|shares)', 1.4],
  ['(bags?|bagged|wins?|won|secures?|secured|lands?|bags) (a |an )?([a-z₹$\\d,.-]+ ){0,4}(orders?|contracts?|deals?)', 2.0],
  ['orders? (wins?|inflows?)', 1.8],
  ['(fii|fpi|dii)s? (buying|inflows?|net buyers?|turn buyers?)', 1.8],
  ['inflows?', 1.2],
  ['(strong|robust|healthy|solid|stellar|blockbuster) (demand|growth|sales|results|numbers|quarter|performance|earnings|show)', 1.8],
  ['(loss|losses) (narrows?|narrowed|shrinks?|shrank)', 2.0],
  ['(narrows?|narrowed) (its )?loss(es)?', 2.0],
  ['(profit|earnings|revenue|sales|income|margins?|ebitda|pat)s? (jumps?|jumped|rises?|rose|surges?|surged|climbs?|climbed|grows?|grew|soars?|soared|up|doubles?|doubled|improves?|improved)', 2.0],
  ['margin expansion', 1.8],
  ['(usfda|fda|regulatory|sebi|government|dcgi) (nod|approval|clearance|go-ahead)', 1.8],
  ['approv(al|es|ed)', 1.2],
  ['inflation (eases|eased|easing|cools|cooled|softens|moderates|slows)', 1.4],
  ['rall(y|ies|ied|ying)', 2.0],
  ['surg(e|es|ed|ing)', 2.0],
  ['soar(s|ed|ing)?', 2.4],
  ['skyrocket(s|ed|ing)?', 2.6],
  ['zoom(s|ed)?', 1.8],
  ['jump(s|ed|ing)?', 1.6],
  ['climb(s|ed|ing)?', 1.4],
  ['gain(s|ed|ing)?', 1.2],
  ['ris(e|es|ing)|rose', 1.1],
  ['advanc(e|es|ed|ing)', 1.0],
  ['outperform(s|ed|ing)?', 1.8],
  ['bullish', 2.0],
  ['optimis(m|tic)', 1.5],
  ['recover(y|s|ed|ing)?', 1.4],
  ['rebound(s|ed|ing)?', 1.5],
  ['tailwinds?', 1.5],
  ['boost(s|ed|ing)?', 1.4],
  ['lift(s|ed|ing)?', 1.2],
  ['accelerat(e|es|ed|ing)', 1.4],
  ['breakout', 1.5],
  ['oversubscribed', 1.8],
  ['(record|strong) ([a-z-]+ )?(sales|revenue|profit|earnings|deliveries|orders)', 2.0],
  ['robust', 1.3],
  ['strong', 0.9],
  ['upbeat', 1.6],
  ['beats?', 1.6],
  ['expan(d|ds|ded|sion)', 0.9],
  ['higher', 0.8],
  ['green', 0.8],
  ['buy rating|rated buy|initiates? .{0,12}buy', 1.8],
  // Bearish
  ['miss(es|ed|ing)? (the )?(street |analyst |consensus )?(estimates|expectations|forecasts|views)', -2.6],
  ['(cuts?|lowers?|lowered|slashes?|slashed|trims?|trimmed) (its )?(fy ?\\d* |full[- ]year |annual )?(revenue |profit |earnings |sales )?(guidance|outlook|forecast)', -2.6],
  ['(costs?|expenses?) (rise|rises|rose|climb|climbs|climbed|jump|jumps|surge|surges|soar|soars)', -1.4],
  ['(weak|weaker|muted|soft|tepid|disappointing|poor|dismal|sluggish|bleak) (revenue |profit |earnings |sales )?(guidance|outlook|results|numbers|quarter|demand|sales|growth|deal wins|earnings|show|performance)', -2.0],
  ['(guidance|outlook|forecast) (cut|lowered|downgraded)', -2.4],
  ['lower circuit', -2.4],
  ['52[- ]week lows?', -1.6],
  ['(record|multi[- ]year|all[- ]time|lifetime) lows?', -2.0],
  ['rate hikes?', -1.4],
  ['hikes? (interest |repo |policy |key )?rates?', -1.4],
  ['downgrade[sd]?', -2.0],
  ['(price )?targets? (cut|lowered|slashed|reduced)', -1.8],
  ['(cuts?|lowers?|slashes?) (price )?targets?', -1.8],
  ['(fii|fpi)s? (selling|outflows?|net sellers?|sell|dump)', -1.8],
  ['outflows?', -1.2],
  ['(profit|earnings|revenue|sales|income|margins?|ebitda|pat)s? (falls?|fell|drops?|dropped|declines?|declined|slumps?|slumped|plunges?|plunged|shrinks?|shrank|down|halves|halved|contracts?|dips?|slides?)', -2.0],
  ['net loss(es)?', -1.8],
  ['loss(es)?', -1.3],
  ['margin (pressure|squeeze|contraction)', -1.8],
  ['(under|faces?|facing) pressure', -1.3],
  ['pressure', -0.7],
  ['plung(e|es|ed|ing)', -2.4],
  ['crash(es|ed|ing)?', -2.8],
  ['slump(s|ed|ing)?', -2.2],
  ['tumbl(e|es|ed|ing)', -2.2],
  ['tank(s|ed|ing)?', -2.2],
  ['sink(s|ing)?|sank', -2.0],
  ['slid(e|es|ing)?', -1.5],
  ['slip(s|ped|ping)?', -1.3],
  ['fall(s|ing)?|fell', -1.4],
  ['drop(s|ped|ping)?', -1.4],
  ['declin(e|es|ed|ing)', -1.4],
  ['dip(s|ped)?', -1.0],
  ['lower', -0.8],
  ['weak(ens|ened|ening|ness|er)?', -1.3],
  ['bearish', -2.0],
  ['sell[- ]?off', -2.4],
  ['underperform(s|ed|ing)?', -1.8],
  ['sell rating|rated sell|initiates? .{0,12}sell', -1.8],
  ['fraud', -3.0],
  ['scam', -2.8],
  ['probe[sd]?', -2.0],
  ['investigation', -1.8],
  ['raid(s|ed)?', -2.2],
  ['penalt(y|ies)', -1.8],
  ['fine[sd]? (of|worth|by)', -1.6],
  ['lawsuits?|sue[sd]?', -1.8],
  ['default(s|ed)?', -2.4],
  ['bankrupt(cy)?|insolven(cy|t)', -3.0],
  ['resign(s|ed|ation)?', -1.4],
  ['layoffs?|lay off|job cuts?|cut(s|ting)? ([\\d,]+ )?jobs', -1.5],
  ['recall(s|ed|ing)?', -1.6],
  ['warning letter', -2.4],
  ['ban(s|ned)?', -1.8],
  ['recession', -2.4],
  ['tariffs?', -1.2],
  ['war', -1.8],
  ['tensions?', -1.3],
  ['volatil(e|ity)', -0.8],
  ['concerns?|worr(y|ies|ied)|fears?', -1.3],
  ['sticky inflation|inflation (stays|remains) (sticky|high|elevated)', -1.6],
  ['inflation', -0.6],
  ['warns?|warning', -1.3],
  ['headwinds?', -1.5],
  ['downturn', -2.0],
  ['delay(s|ed)?', -1.0],
  ['shut ?downs?', -1.8],
  ['dilution', -1.4],
  ['pledge[sd]?', -1.2],
  ['glitch(es)?', -1.2],
  ['disappoint(s|ed|ing|ment)?', -1.8],
  ['(rupee|inr) (weakens|falls|slips|hits record low|depreciates|slides)', -1.2],
  ['(crude|oil) (prices? )?(surge|surges|jumps|spikes|soars)', -1.0],
  ['red', -0.6]
].map(([src, w]) => ({ re: new RegExp('(?<![a-z0-9])(?:' + src + ')(?![a-z0-9])', 'gi'), w }));

const NEGATORS = /(?:^|[^a-z])(not|no|never|fails? to|failed to|without|unlikely to|hardly|nor|isn't|wasn't|won't|doesn't|didn't|can't)(?:[^a-z]|$)/i;
const BOOST = /(?:^|[^a-z])(sharply|massive|huge|steep|steeply|big|biggest|record|mega|strongly|heavily|significantly|deep|deeply|multi-year)(?:[^a-z]|$)/i;
const DAMP = /(?:^|[^a-z])(slightly|marginally|modest|modestly|mildly|little|flat)(?:[^a-z]|$)/i;

function scoreHeadline(text) {
  const lower = text.toLowerCase();
  const raw = [];
  for (const { re, w } of LEX) {
    re.lastIndex = 0; let m;
    while ((m = re.exec(lower))) { raw.push({ s: m.index, e: m.index + m[0].length, w, t: text.slice(m.index, m.index + m[0].length) }); if (m[0].length === 0) re.lastIndex++; }
  }
  raw.sort((a, b) => (b.e - b.s) - (a.e - a.s) || a.s - b.s);
  const hits = [];
  for (const h of raw) if (!hits.some(x => h.s < x.e && h.e > x.s)) hits.push(h);
  hits.sort((a, b) => a.s - b.s);
  const concession = (() => { const m = /(?:^|[^a-z])(despite|even as|although|though)(?:[^a-z])/.exec(lower); return m ? m.index : -1; })();
  let sum = 0, prevEnd = 0;
  for (const h of hits) {
    let w = h.w;
    const before = lower.slice(Math.max(prevEnd, h.s - 24), h.s);
    prevEnd = h.e;
    const near = lower.slice(Math.max(0, h.s - 16), Math.min(lower.length, h.e + 12));
    if (NEGATORS.test(before)) { w = -w * 0.8; h.neg = true; }
    if (BOOST.test(near)) w *= 1.4; else if (DAMP.test(near)) w *= 0.5;
    if (concession >= 0 && h.s > concession) w *= 0.3;
    h.v = w; sum += w;
  }
  const pcts = [...lower.matchAll(/(\d+(?:\.\d+)?)\s?(%|per ?cent)/g)].map(m => parseFloat(m[1])).filter(n => n < 1000);
  if (pcts.length && sum !== 0) sum *= 1 + Math.min(Math.max(...pcts), 15) / 15 * 0.5;
  const score = Math.tanh(sum / 4.5);
  const label = score > 0.15 ? 'Bullish' : score < -0.15 ? 'Bearish' : 'Neutral';
  const conf = hits.length ? Math.min(0.95, 0.35 + 0.12 * hits.length + 0.08 * Math.abs(sum)) : 0.2;
  return { score: +score.toFixed(3), label, conf: +conf.toFixed(2), hits: hits.map(h => ({ s: h.s, e: h.e, v: +h.v.toFixed(2), t: h.t, neg: !!h.neg })) };
}

// ---------- Tickers, indices & themes ----------
// [symbol, name, sector, market, aliases]. An alias starting with "=" is matched case-sensitively; all-caps aliases of 4 letters or fewer are too.
const ENTS = [
  ['RELIANCE','Reliance Industries','Energy','IN',['Reliance Industries','Reliance','RIL','Jio']],
  ['TCS','Tata Consultancy Services','IT','IN',['TCS','Tata Consultancy']],
  ['INFY','Infosys','IT','IN',['Infosys','INFY']],
  ['WIPRO','Wipro','IT','IN',['Wipro']],
  ['HCLTECH','HCLTech','IT','IN',['HCLTech','HCL Tech','HCL Technologies']],
  ['TECHM','Tech Mahindra','IT','IN',['Tech Mahindra']],
  ['HDFCBANK','HDFC Bank','Banking','IN',['HDFC Bank']],
  ['ICICIBANK','ICICI Bank','Banking','IN',['ICICI Bank','ICICI']],
  ['SBIN','State Bank of India','Banking','IN',['State Bank of India','SBI']],
  ['KOTAKBANK','Kotak Mahindra Bank','Banking','IN',['Kotak Mahindra Bank','Kotak Bank','Kotak']],
  ['AXISBANK','Axis Bank','Banking','IN',['Axis Bank']],
  ['INDUSINDBK','IndusInd Bank','Banking','IN',['IndusInd Bank','IndusInd']],
  ['BAJFINANCE','Bajaj Finance','Financials','IN',['Bajaj Finance']],
  ['PAYTM','Paytm (One 97)','Financials','IN',['Paytm','One 97']],
  ['LICI','LIC','Financials','IN',['LIC','Life Insurance Corporation']],
  ['HINDUNILVR','Hindustan Unilever','FMCG','IN',['Hindustan Unilever','HUL']],
  ['ITC','ITC','FMCG','IN',['ITC']],
  ['NESTLEIND','Nestle India','FMCG','IN',['Nestle India']],
  ['ASIANPAINT','Asian Paints','Consumer','IN',['Asian Paints']],
  ['TITAN','Titan Company','Consumer','IN',['Titan']],
  ['DMART','Avenue Supermarts','Consumer','IN',['DMart','Avenue Supermarts']],
  ['ETERNAL','Eternal (Zomato)','Consumer Tech','IN',['Zomato','Eternal','Blinkit']],
  ['NYKAA','Nykaa','Consumer Tech','IN',['Nykaa']],
  ['LT','Larsen & Toubro','Infra','IN',['Larsen & Toubro','Larsen','L&T']],
  ['ULTRACEMCO','UltraTech Cement','Infra','IN',['UltraTech Cement','UltraTech']],
  ['ADANIENT','Adani Enterprises','Infra','IN',['Adani Enterprises','Adani Group','Adani group','Adani']],
  ['ADANIPORTS','Adani Ports','Infra','IN',['Adani Ports']],
  ['BHARTIARTL','Bharti Airtel','Telecom','IN',['Bharti Airtel','Airtel']],
  ['IDEA','Vodafone Idea','Telecom','IN',['Vodafone Idea']],
  ['MARUTI','Maruti Suzuki','Auto','IN',['Maruti Suzuki','Maruti']],
  ['TATAMOTORS','Tata Motors','Auto','IN',['Tata Motors','JLR','Jaguar Land Rover']],
  ['M&M','Mahindra & Mahindra','Auto','IN',['Mahindra & Mahindra','M&M']],
  ['BAJAJ-AUTO','Bajaj Auto','Auto','IN',['Bajaj Auto']],
  ['TATASTEEL','Tata Steel','Metals','IN',['Tata Steel']],
  ['JSWSTEEL','JSW Steel','Metals','IN',['JSW Steel']],
  ['HINDALCO','Hindalco','Metals','IN',['Hindalco']],
  ['VEDL','Vedanta','Metals','IN',['Vedanta']],
  ['SUNPHARMA','Sun Pharma','Pharma','IN',['Sun Pharma','Sun Pharmaceutical']],
  ['DRREDDY',"Dr Reddy's",'Pharma','IN',["Dr Reddy's","Dr. Reddy's",'Dr Reddys']],
  ['CIPLA','Cipla','Pharma','IN',['Cipla']],
  ['NTPC','NTPC','Power','IN',['NTPC']],
  ['POWERGRID','Power Grid','Power','IN',['Power Grid']],
  ['TATAPOWER','Tata Power','Power','IN',['Tata Power']],
  ['ONGC','ONGC','Energy','IN',['ONGC']],
  ['COALINDIA','Coal India','Energy','IN',['Coal India']],
  ['HAL','Hindustan Aeronautics','Defence','IN',['Hindustan Aeronautics','HAL']],
  ['BEL','Bharat Electronics','Defence','IN',['Bharat Electronics']],
  ['IRCTC','IRCTC','Consumer','IN',['IRCTC']],
  ['BANKNIFTY','Nifty Bank','Index','IN',['Bank Nifty','Nifty Bank','BankNifty']],
  ['NIFTY','Nifty 50','Index','IN',['Nifty 50','Nifty']],
  ['SENSEX','BSE Sensex','Index','IN',['Sensex','Dalal Street']],
  ['RBI','Reserve Bank of India','Macro','IN',['RBI','Reserve Bank']],
  ['INR','Indian rupee','Currency','IN',['rupee','INR']],
  ['AAPL','Apple','Tech','US',['Apple','iPhone']],
  ['MSFT','Microsoft','Tech','US',['Microsoft','Azure']],
  ['NVDA','Nvidia','Semiconductors','US',['Nvidia']],
  ['AMD','AMD','Semiconductors','US',['AMD']],
  ['INTC','Intel','Semiconductors','US',['Intel']],
  ['TSM','TSMC','Semiconductors','US',['TSMC']],
  ['GOOGL','Alphabet','Tech','US',['Alphabet','Google']],
  ['AMZN','Amazon','Tech','US',['Amazon','AWS']],
  ['META','Meta Platforms','Tech','US',['Meta Platforms','=Meta','Facebook','Instagram']],
  ['TSLA','Tesla','Auto','US',['Tesla']],
  ['NFLX','Netflix','Media','US',['Netflix']],
  ['DIS','Disney','Media','US',['Disney']],
  ['JPM','JPMorgan Chase','Banking','US',['JPMorgan','JP Morgan']],
  ['GS','Goldman Sachs','Banking','US',['Goldman Sachs','Goldman']],
  ['BAC','Bank of America','Banking','US',['Bank of America']],
  ['XOM','ExxonMobil','Energy','US',['ExxonMobil','Exxon']],
  ['BA','Boeing','Industrials','US',['Boeing']],
  ['WMT','Walmart','Consumer','US',['Walmart']],
  ['PFE','Pfizer','Pharma','US',['Pfizer']],
  ['LLY','Eli Lilly','Pharma','US',['Eli Lilly']],
  ['BABA','Alibaba','Tech','US',['Alibaba']],
  ['SPX','S&P 500','Index','US',['S&P 500','S&P']],
  ['NDX','Nasdaq','Index','US',['Nasdaq']],
  ['DJI','Dow Jones','Index','US',['Dow Jones','=Dow']],
  ['FED','US Federal Reserve','Macro','US',['Federal Reserve','=Fed','FOMC','Powell']],
  ['GOLD','Gold','Commodities','GL',['gold']],
  ['CRUDE','Crude oil','Commodities','GL',['crude','Brent','oil prices']],
  ['BTC','Bitcoin','Crypto','GL',['Bitcoin','BTC']]
];
const ENT_BY_SYM = Object.fromEntries(ENTS.map(([sym, name, sector, mkt]) => [sym, { sym, name, sector, mkt }]));
const esc_re = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const ENT_PATTERNS = [];
for (const [sym, , , , aliases] of ENTS) for (let a of aliases) {
  let cs = false;
  if (a.startsWith('=')) { cs = true; a = a.slice(1); }
  else if (/^[A-Z&]{2,4}$/.test(a)) cs = true;
  const body = esc_re(a.trim());
  ENT_PATTERNS.push({ sym, len: a.length, re: new RegExp('(?<![A-Za-z0-9&])' + body + '(?![A-Za-z0-9&])', cs ? 'g' : 'gi') });
}
function extractEntities(text) {
  const raw = [];
  for (const p of ENT_PATTERNS) { p.re.lastIndex = 0; let m; while ((m = p.re.exec(text))) raw.push({ s: m.index, e: m.index + m[0].length, sym: p.sym }); }
  for (const m of text.matchAll(/(?:\$|NSE:|BSE:|NASDAQ:|NYSE:)([A-Z][A-Z0-9&-]{0,11})\b/g)) raw.push({ s: m.index, e: m.index + m[0].length, sym: m[1], tag: m[0].startsWith('$') || /^NAS|^NY/.test(m[0]) ? 'US' : 'IN' });
  raw.sort((a, b) => (b.e - b.s) - (a.e - a.s));
  const kept = [];
  for (const r of raw) if (!kept.some(k => r.s < k.e && r.e > k.s)) kept.push(r);
  kept.sort((a, b) => a.s - b.s);
  const syms = [];
  for (const k of kept) if (!syms.includes(k.sym)) syms.push(k.sym);
  return { syms, extra: kept.filter(k => k.tag && !ENT_BY_SYM[k.sym]).map(k => ({ sym: k.sym, mkt: k.tag })) };
}

const ent = (sym, custom) => ENT_BY_SYM[sym] || (custom && custom[sym]) || { sym, name: sym, sector: 'Other', mkt: '' };

// Effective score of an item: AI result wins over the instant engine.
function effective(it) {
  if (it.ai) { const w = { high: 1, medium: 0.7, low: 0.4 }[it.ai.impact] || 0.7; return { score: it.ai.score, label: it.ai.label, w, src: 'ai' }; }
  return { score: it.lex.score, label: it.lex.label, w: it.lex.conf, src: 'lex' };
}
const symbolsOf = it => it.ai && Array.isArray(it.ai.tickers) ? [...new Set([...(it.syms || []), ...it.ai.tickers])] : (it.syms || []);
const labelOf = score => score > 0.15 ? 'Bullish' : score < -0.15 ? 'Bearish' : 'Neutral';
const moodLabel = v => v < 20 ? 'Extreme fear' : v < 40 ? 'Fear' : v <= 60 ? 'Neutral' : v <= 80 ? 'Greed' : 'Extreme greed';

function mood(items) {
  let sw = 0, s = 0;
  for (const it of items) { const e = effective(it); s += e.score * e.w; sw += e.w; }
  const avg = sw ? s / sw : 0;
  const value = Math.round(Math.max(0, Math.min(100, 50 + 50 * Math.max(-1, Math.min(1, avg * 1.5)))));
  return { net: +avg.toFixed(3), mood: value, label: moodLabel(value) };
}
function aggregate(items, custom) {
  const m = {};
  for (const it of items) { const e = effective(it); for (const s of symbolsOf(it)) { (m[s] = m[s] || { sym: s, sum: 0, n: 0 }); m[s].sum += e.score; m[s].n++; } }
  return Object.values(m).map(x => { const en = ent(x.sym, custom); return { sym: x.sym, name: en.name, sector: en.sector, mkt: en.mkt, n: x.n, avg: +(x.sum / x.n).toFixed(3) }; });
}
function summarize(items, custom) {
  const counts = { Bullish: 0, Neutral: 0, Bearish: 0 };
  for (const it of items) counts[effective(it).label]++;
  return { count: items.length, counts, ...mood(items), tickers: aggregate(items, custom).sort((a, b) => b.n - a.n || Math.abs(b.avg) - Math.abs(a.avg)) };
}
function analyze(text) {
  const lex = scoreHeadline(text);
  const { syms, extra } = extractEntities(text);
  return { lex, syms, extra };
}

return { LEX_SIZE: LEX.length, ENTS, ENT_BY_SYM, scoreHeadline, extractEntities, analyze, entity: ent, effective, symbolsOf, labelOf, moodLabel, mood, aggregate, summarize };
});
