/* MoodTape dashboard. Talks to /api/* and uses window.MoodEngine (engine.js) for instant scoring. */
(function () {
'use strict';
const E = window.MoodEngine;
const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(k); } catch {} }
};
const fmt = n => (n > 0 ? '+' : n < 0 ? '−' : '') + Math.abs(n).toFixed(2);
const cap = s => s ? s[0].toUpperCase() + s.slice(1) : '';
const cls = l => l === 'Bullish' ? 'bull' : l === 'Bearish' ? 'bear' : 'neu';
const arrow = l => l === 'Bullish' ? '▲' : l === 'Bearish' ? '▼' : '•';
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

// ---------- State ----------
const S = {
  cfg: { features: { auth: false, payments: false, ai: false }, plans: { free: { watchlist: 5, aiDaily: 3, csv: false }, pro: { watchlist: 100, aiDaily: 100, csv: true, price: '$9 / month' } } },
  me: null, session: store.get('mt.session', null),
  live: [], own: store.get('mt.own', []), extra: [], aiCache: store.get('mt.ai', {}),
  watch: store.get('mt.watch', []), market: store.get('mt.market', 'ALL'),
  sent: 'all', q: '', watchOnly: false, sort: 'new', focus: null, sector: null, showAll: 30, showAllStocks: false,
  fetchedAt: 0, liveOk: null, sample: false, loading: false
};
let ctl = null;

const items = () => {
  const seen = new Set(); const out = [];
  for (const it of [...S.own, ...S.extra, ...S.live]) { if (seen.has(it.id)) continue; seen.add(it.id); out.push(S.aiCache[it.id] ? { ...it, ai: S.aiCache[it.id] } : it); }
  return out;
};
const eff = E.effective, allSyms = E.symbolsOf, ent = s => E.entity(s);
function itemSector(it) {
  if (it.ai && it.ai.sector) return it.ai.sector;
  const all = allSyms(it).map(ent);
  const real = all.filter(e => !['Index', 'Macro', 'Currency'].includes(e.sector));
  return (real[0] || all[0] || {}).sector || null;
}
function inMarket(it) {
  if (S.market === 'ALL') return true;
  const mk = new Set(allSyms(it).map(s => ent(s).mkt).concat(it.mkt ? [it.mkt] : []).filter(Boolean));
  if (!mk.size) return true;
  if (S.market === 'IN') return mk.has('IN');
  return mk.has('US') || mk.has('GL');
}
const marketItems = () => items().filter(inMarket);
function feedItems() {
  const q = S.q.trim().toLowerCase();
  const list = marketItems().filter(it => {
    if (S.sent !== 'all' && eff(it).label !== S.sent) return false;
    if (S.focus && !allSyms(it).includes(S.focus)) return false;
    if (S.sector && itemSector(it) !== S.sector) return false;
    if (S.watchOnly && !allSyms(it).some(s => S.watch.includes(s))) return false;
    if (q && !(it.text.toLowerCase().includes(q) || (it.source || '').toLowerCase().includes(q) || allSyms(it).some(s => s.toLowerCase().includes(q) || ent(s).name.toLowerCase().includes(q)))) return false;
    return true;
  });
  const by = { new: (a, b) => b.time - a.time, strong: (a, b) => Math.abs(eff(b).score) - Math.abs(eff(a).score), bull: (a, b) => eff(b).score - eff(a).score, bear: (a, b) => eff(a).score - eff(b).score }[S.sort];
  return list.sort(by);
}
const isPro = () => !S.cfg.features.auth || (S.me && S.me.plan === 'pro');
const limits = () => S.cfg.plans[S.me && S.me.plan === 'pro' ? 'pro' : 'free'];

function ago(t) {
  const d = (Date.now() - t) / 60000;
  if (d < 1) return 'just now';
  if (d < 60) return Math.round(d) + 'm ago';
  if (d < 1440) { const h = Math.floor(d / 60), m = Math.round(d % 60); return h + 'h ' + (m ? m + 'm ' : '') + 'ago'; }
  return new Date(t).toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) + ', ' + new Date(t).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
}

// ---------- API ----------
async function api(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth && S.session) { await ensureFresh(); if (S.session) headers.Authorization = 'Bearer ' + S.session.access_token; }
  const r = await fetch(path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error((d.error && d.error.message) || 'Request failed.'), { status: r.status, code: d.error && d.error.code, data: d.error });
  return d;
}

// ---------- Auth (Supabase over REST, no SDK) ----------
const sb = () => S.cfg.supabase;
function saveSession(s) { S.session = s; if (s) store.set('mt.session', s); else store.del('mt.session'); }
function readHashSession() {
  if (!location.hash || location.hash.indexOf('access_token=') < 0) {
    if (/error_description=/.test(location.hash)) { const p = new URLSearchParams(location.hash.slice(1)); toast(p.get('error_description') || 'Sign-in failed.'); history.replaceState(null, '', location.pathname + location.search); }
    return;
  }
  const p = new URLSearchParams(location.hash.slice(1));
  saveSession({ access_token: p.get('access_token'), refresh_token: p.get('refresh_token'), expires_at: Date.now() + (Number(p.get('expires_in')) || 3600) * 1000 });
  history.replaceState(null, '', location.pathname + location.search);
}
async function ensureFresh() {
  if (!S.session || !sb()) return;
  if (S.session.expires_at - Date.now() > 60000) return;
  try {
    const r = await fetch(sb().url + '/auth/v1/token?grant_type=refresh_token', { method: 'POST', headers: { apikey: sb().anonKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: S.session.refresh_token }) });
    if (!r.ok) throw new Error();
    const d = await r.json();
    saveSession({ access_token: d.access_token, refresh_token: d.refresh_token, expires_at: Date.now() + (d.expires_in || 3600) * 1000 });
  } catch { saveSession(null); S.me = null; renderAccount(); }
}
async function sendMagicLink(email) {
  const r = await fetch(sb().url + '/auth/v1/otp?redirect_to=' + encodeURIComponent(location.origin + '/app'), { method: 'POST', headers: { apikey: sb().anonKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ email, create_user: true }) });
  if (!r.ok) { const d = await r.json().catch(() => ({})); throw new Error(d.msg || d.error_description || 'Could not send the link. Check the address and try again.'); }
}
function googleSignIn() { location.href = sb().url + '/auth/v1/authorize?provider=google&redirect_to=' + encodeURIComponent(location.origin + '/app'); }
async function signOut() {
  try { if (S.session && sb()) await fetch(sb().url + '/auth/v1/logout', { method: 'POST', headers: { apikey: sb().anonKey, Authorization: 'Bearer ' + S.session.access_token } }); } catch {}
  saveSession(null); S.me = null; render(); toast('Signed out.');
}
async function loadMe() {
  if (!S.cfg.features.auth || !S.session) { S.me = null; return; }
  try {
    S.me = await api('/api/me');
    // Merge guest watchlist into the account once
    const merged = [...new Set([...(S.me.watchlist || []), ...S.watch])].slice(0, S.me.limits.watchlist);
    if (merged.length !== (S.me.watchlist || []).length) { try { await api('/api/watchlist', { method: 'PUT', body: { symbols: merged } }); } catch {} }
    S.watch = merged; store.set('mt.watch', S.watch);
  } catch (e) { if (e.status === 401) saveSession(null); S.me = null; }
}

// ---------- Live news ----------
async function loadNews({ quiet = false } = {}) {
  if (S.loading) return; S.loading = true;
  setLive('loading');
  try {
    const d = await api('/api/news?market=ALL', { auth: false });
    if (!d.items || !d.items.length) throw new Error('No headlines returned');
    S.live = d.items; S.fetchedAt = d.fetchedAt || Date.now(); S.liveOk = true; S.sample = false;
    store.set('mt.liveCache', { items: S.live, fetchedAt: S.fetchedAt });
  } catch (e) {
    S.liveOk = false;
    const c = store.get('mt.liveCache', null);
    if (c && c.items && c.items.length && Date.now() - c.fetchedAt < 6 * 3600e3) { S.live = c.items; S.fetchedAt = c.fetchedAt; S.sample = false; }
    else if (!S.live.length) { S.live = sampleItems(); S.sample = true; S.fetchedAt = Date.now(); }
  } finally { S.loading = false; setLive(); render(); }
}
function setLive(state) {
  const el = $('live'), t = $('live-txt');
  if (state === 'loading') { t.textContent = 'Updating…'; return; }
  el.classList.toggle('off', !S.liveOk);
  t.textContent = S.sample ? 'Sample data' : S.liveOk ? 'Live · updated ' + ago(S.fetchedAt) : 'Offline · ' + ago(S.fetchedAt);
}
async function findStock(raw) {
  const q = raw.trim(); if (!q) return;
  const up = q.toUpperCase();
  let sym = E.ENT_BY_SYM[up] ? up : null;
  if (!sym) { const hit = E.ENTS.find(e => e[1].toLowerCase() === q.toLowerCase() || e[4].some(a => a.replace(/^=/, '').toLowerCase() === q.toLowerCase())); if (hit) sym = hit[0]; }
  if (!sym && /^[A-Z0-9&.\-]{1,15}$/.test(up)) sym = up;
  if (!sym) { toast('Type a stock symbol or company name, e.g. RELIANCE or Infosys.'); return; }
  $('status').textContent = `Fetching ${sym} news…`;
  try {
    const d = await api('/api/news?symbol=' + encodeURIComponent(sym), { auth: false });
    const got = (d.items || []).map(it => allSyms(it).includes(sym) ? it : { ...it, syms: [...it.syms, sym] });
    const ids = new Set(S.extra.map(i => i.id));
    S.extra = [...got.filter(i => !ids.has(i.id)), ...S.extra].slice(0, 400);
    S.focus = sym; S.sector = null; S.showAll = 30;
    if (S.market !== 'ALL' && !inMarket({ syms: [sym], mkt: '' })) S.market = 'ALL';
    $('status').textContent = '';
    render();
    if (!got.length) toast(`No recent news found for ${sym}.`);
    $('focus').scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'nearest' });
  } catch { $('status').textContent = ''; toast('Could not fetch news for that stock. Try again.'); }
}

// ---------- Rendering ----------
function render() {
  const its = marketItems();
  renderSummary(its); renderTape(its); renderFeed(); renderStocks(its); renderSectors(its); renderTimeline(its); renderFocus(its); renderAccount();
  $('demo-note').hidden = !S.sample;
  const aiOn = S.cfg.features.ai;
  $('b-ai').hidden = $('b-brief').hidden = !aiOn;
  $('b-csv').innerHTML = `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M8 2v8M5 7l3 3 3-3M3 13h10"/></svg>Export CSV${isPro() ? '' : ' <span class="badge pro">Pro</span>'}`;
  const aiN = items().filter(i => i.ai).length;
  $('status').textContent = $('status').textContent || (aiN ? `AI checked ${aiN} headlines` : '');
  for (const b of document.querySelectorAll('.seg button')) b.setAttribute('aria-pressed', String(b.dataset.m === S.market));
}

function arcPath(a0, a1, r) {
  const p = a => [120 + r * Math.cos(a * Math.PI / 180), 122 - r * Math.sin(a * Math.PI / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M${x0.toFixed(2)} ${y0.toFixed(2)} A${r} ${r} 0 0 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`;
}
function drawArcs() {
  const cols = ['var(--bear)', 'color-mix(in oklab, var(--bear) 55%, var(--neutral))', 'var(--neutral)', 'color-mix(in oklab, var(--bull) 55%, var(--neutral))', 'var(--bull)'];
  $('arcs').innerHTML = cols.map((c, i) => `<path class="seg-arc" style="stroke:${c}" d="${arcPath(180 - i * 36 - 1.2, 180 - (i + 1) * 36 + 1.2, 96)}"></path>`).join('');
}

function renderSummary(its) {
  const m = E.mood(its), n = its.length;
  $('needle').style.transform = `rotate(${n ? (m.mood - 50) * 1.8 : 0}deg)`;
  $('mood-val').textContent = n ? m.mood : '–';
  $('mood-lbl').textContent = n ? m.label : 'No headlines yet';
  $('mood-lbl').style.color = !n ? '' : m.mood > 60 ? 'var(--bull-ink)' : m.mood < 40 ? 'var(--bear-ink)' : '';
  $('mood-n').textContent = n ? n + ' headlines' : '';
  let shift = '';
  if (n >= 6) {
    const sorted = [...its].sort((a, b) => a.time - b.time), cut = Math.floor(sorted.length * 2 / 3);
    const early = E.mood(sorted.slice(0, cut)).mood, late = E.mood(sorted.slice(cut)).mood, d = late - early;
    shift = Math.abs(d) < 3 ? `Steady: latest headlines read ${late}, same as earlier` : `${d > 0 ? 'Improving ▲' : 'Worsening ▼'} latest headlines read ${late} vs ${early} earlier`;
  }
  $('mood-shift').textContent = shift;
  const c = { Bullish: 0, Neutral: 0, Bearish: 0 };
  for (const it of its) c[eff(it).label]++;
  $('c-b').textContent = c.Bullish; $('c-n').textContent = c.Neutral; $('c-r').textContent = c.Bearish;
  const sp = $('split').children;
  sp[0].style.flexGrow = c.Bullish; sp[1].style.flexGrow = c.Neutral; sp[2].style.flexGrow = c.Bearish;
  for (const x of sp) x.hidden = !n;
  $('split-n').textContent = n ? Math.round(c.Bullish / n * 100) + '% bullish' : '';
  $('net').textContent = fmt(m.net);
  $('net').style.color = m.net > 0.05 ? 'var(--bull-ink)' : m.net < -0.05 ? 'var(--bear-ink)' : '';
  $('ratio').textContent = c.Bearish ? (c.Bullish / c.Bearish).toFixed(2) + ' : 1' : c.Bullish ? 'All bullish' : '–';
  const agg = E.aggregate(its).filter(a => !['Macro', 'Currency'].includes(a.sector));
  const up = agg.filter(a => a.avg > 0.05).sort((a, b) => b.avg - a.avg || b.n - a.n).slice(0, 4);
  const dn = agg.filter(a => a.avg < -0.05).sort((a, b) => a.avg - b.avg || b.n - a.n).slice(0, 4);
  const row = a => `<button class="mv" data-sym="${esc(a.sym)}"><span class="mv-l"><span class="sym">${esc(a.sym)}</span><span class="sub">${esc(a.name)} · ${a.n} ${a.n === 1 ? 'headline' : 'headlines'}</span></span><span class="pill ${a.avg > 0 ? 'bull' : 'bear'}">${fmt(a.avg)}</span></button>`;
  $('mv-up').innerHTML = up.map(row).join('') || '<p class="sub">No bullish stocks yet</p>';
  $('mv-dn').innerHTML = dn.map(row).join('') || '<p class="sub">No bearish stocks yet</p>';
}

function renderTape(its) {
  const agg = E.aggregate(its).sort((a, b) => b.n - a.n || Math.abs(b.avg) - Math.abs(a.avg)).slice(0, 24);
  if (!agg.length) { $('tape').innerHTML = '<span class="tape-empty">Sentiment by ticker appears here</span>'; $('tape').style.animation = 'none'; return; }
  $('tape').style.animation = '';
  const one = agg.map(a => { const c = a.avg > 0.05 ? 'up' : a.avg < -0.05 ? 'dn' : 'fl'; return `<button class="tk" data-sym="${esc(a.sym)}" tabindex="-1"><b>${esc(a.sym)}</b><span class="${c}">${c === 'up' ? '▲' : c === 'dn' ? '▼' : '•'} ${fmt(a.avg)}</span></button>`; }).join('');
  $('tape').innerHTML = one + one;
}

function highlight(it) {
  let out = '', i = 0;
  if (!it.ai && it.lex && it.lex.hits) for (const h of it.lex.hits) { out += esc(it.text.slice(i, h.s)) + `<span class="${h.v > 0 ? 'pos' : 'neg'}">${esc(it.text.slice(h.s, h.e))}</span>`; i = h.e; }
  out += esc(it.text.slice(i));
  return it.link ? `<a href="${esc(it.link)}" target="_blank" rel="noopener noreferrer nofollow">${out}</a>` : out;
}
function renderFeed() {
  const all = marketItems();
  const cnt = { all: all.length, Bullish: 0, Bearish: 0, Neutral: 0 };
  for (const it of all) cnt[eff(it).label]++;
  $('fc-all').textContent = cnt.all; $('fc-b').textContent = cnt.Bullish; $('fc-r').textContent = cnt.Bearish; $('fc-n').textContent = cnt.Neutral;
  for (const b of document.querySelectorAll('#sent-filter [data-s]')) b.setAttribute('aria-pressed', String(b.dataset.s === S.sent));
  $('watch-only').setAttribute('aria-pressed', String(S.watchOnly));
  const list = feedItems();
  $('feed-n').textContent = list.length !== all.length ? `${list.length} of ${all.length}` : '';
  if (!all.length) { $('feed').innerHTML = `<div class="empty"><b>${S.loading || S.liveOk === null ? 'Loading live headlines…' : 'No headlines yet'}</b>${S.liveOk === false ? 'The news sources did not answer. Try refreshing, or add your own headlines.' : ''}</div>`; return; }
  if (!list.length) { $('feed').innerHTML = `<div class="empty"><b>No headlines match these filters</b>${S.watchOnly && !S.watch.length ? 'Star stocks in the Stocks &amp; themes list to build your watchlist.' : 'Try another filter or clear the search.'}</div>`; return; }
  const shown = list.slice(0, S.showAll);
  $('feed').innerHTML = shown.map(it => {
    const e = eff(it), c = cls(e.label);
    const tags = allSyms(it).map(s => `<button class="tag" data-sym="${esc(s)}" title="${esc(ent(s).name)}">${S.watch.includes(s) ? '★ ' : ''}${esc(s)}</button>`).join('');
    const ai = it.ai ? `<span class="ai-tag">AI · ${esc(cap(it.ai.impact))} impact · ${esc(it.ai.horizon)}</span>` : '';
    const reason = it.ai && it.ai.reason ? `<div class="reason"><b>AI</b>${esc(it.ai.reason)}</div>` : '';
    const why = !it.ai && it.lex && it.lex.hits && it.lex.hits.length ? `<div class="why">Signals: ${it.lex.hits.map(h => `${esc(h.t.toLowerCase())}${h.neg ? ' (negated)' : ''} ${fmt(h.v)}`).join(' · ')}</div>` : '';
    const own = it.own ? '<span class="badge">Your headline</span>' : '';
    return `<article class="item"><div class="score ${c}" title="${e.src === 'ai' ? 'AI score' : 'Instant engine score'}"><b>${fmt(e.score)}</b><small>${arrow(e.label)} ${e.label}</small></div><div style="min-width:0"><p class="hl">${highlight(it)}</p><div class="meta"><span>${esc(ago(it.time))}</span>${it.source ? `<span>${esc(it.source)}</span>` : ''}${own}${tags}${ai}</div>${reason}${why}</div></article>`;
  }).join('') + (list.length > shown.length ? `<button class="more" data-act="more">Show ${Math.min(30, list.length - shown.length)} more of ${list.length - shown.length}</button>` : '');
}

function renderStocks(its) {
  const agg = E.aggregate(its).sort((a, b) => (S.watch.includes(b.sym) - S.watch.includes(a.sym)) || b.n - a.n || Math.abs(b.avg) - Math.abs(a.avg));
  if (!agg.length) { $('stocks').innerHTML = '<p class="sub" style="white-space:normal">Stocks named in the headlines appear here, with their average sentiment.</p>'; return; }
  const lim = S.showAllStocks ? agg.length : 12;
  $('stocks').innerHTML = agg.slice(0, lim).map(a => {
    const w = Math.min(50, Math.abs(a.avg) * 50), on = S.watch.includes(a.sym);
    return `<div class="stk"><button class="star" data-star="${esc(a.sym)}" aria-pressed="${on}" aria-label="${on ? 'Remove from' : 'Add to'} watchlist: ${esc(a.sym)}">${on ? '★' : '☆'}</button><button class="stk-name" data-sym="${esc(a.sym)}"><span class="sym">${esc(a.sym)}</span><span class="sub">${esc(a.name)} · ${esc(a.sector)}</span></button><div class="track" title="${fmt(a.avg)}"><i class="${a.avg >= 0 ? 'up' : 'dn'}" style="width:${w}%"></i></div><div class="stk-v">${fmt(a.avg)}<small>${a.n}</small></div></div>`;
  }).join('') + (agg.length > 12 ? `<button class="link" data-act="stocks">${S.showAllStocks ? 'Show top 12' : `Show all ${agg.length}`}</button>` : '');
}

function renderSectors(its) {
  const m = {};
  for (const it of its) { const s = itemSector(it); if (!s) continue; (m[s] = m[s] || { s, sum: 0, n: 0 }); m[s].sum += eff(it).score; m[s].n++; }
  const list = Object.values(m).map(x => ({ ...x, avg: x.sum / x.n })).sort((a, b) => b.n - a.n);
  $('sec-clear').innerHTML = S.sector ? `<button class="link" style="padding:0" data-act="sec-clear">Clear ${esc(S.sector)}</button>` : '';
  if (!list.length) { $('heat').innerHTML = '<p class="sub" style="white-space:normal">Sectors appear once headlines name a stock.</p>'; return; }
  $('heat').innerHTML = list.map(x => {
    const pct = Math.round(Math.min(1, Math.abs(x.avg) / 0.7) * 55);
    const bg = `color-mix(in oklab, var(--${x.avg >= 0 ? 'bull' : 'bear'}) ${pct}%, var(--cell-neutral))`;
    return `<button class="cell" data-sector="${esc(x.s)}" aria-pressed="${S.sector === x.s}" style="background:${bg}" title="${esc(x.s)}: average ${fmt(x.avg)} across ${x.n} headlines"><span class="n">${esc(x.s)}</span><span class="v">${fmt(x.avg)}<small>${x.n}</small></span></button>`;
  }).join('');
}

let tlBuckets = [];
function renderTimeline(its) {
  const box = $('tl');
  if (its.length < 2) { box.innerHTML = '<p class="sub" style="white-space:normal">Hourly sentiment appears once there are a few headlines.</p>'; return; }
  const H = 3600000, m = {};
  for (const it of its) { const k = Math.floor(it.time / H); (m[k] = m[k] || { k, sum: 0, n: 0 }); m[k].sum += eff(it).score; m[k].n++; }
  const keys = Object.keys(m).map(Number).sort((a, b) => a - b);
  let first = keys[0]; const last = keys[keys.length - 1];
  if (last - first > 23) first = last - 23;
  tlBuckets = [];
  for (let k = first; k <= last; k++) tlBuckets.push(m[k] ? { k, n: m[k].n, avg: m[k].sum / m[k].n } : { k, n: 0, avg: 0 });
  const W = Math.max(260, box.clientWidth || 320), Ht = 150, padL = 34, padR = 6, padT = 10, padB = 22;
  const maxAbs = Math.max(0.25, Math.ceil(Math.max(...tlBuckets.map(b => Math.abs(b.avg))) * 4) / 4);
  const y = v => padT + (1 - (v + maxAbs) / (2 * maxAbs)) * (Ht - padT - padB);
  const n = tlBuckets.length, bw = (W - padL - padR) / n, gap = Math.min(6, bw * 0.25);
  const lbl = k => new Date(k * H).toLocaleTimeString(undefined, { hour: 'numeric' });
  const step = Math.ceil(n / Math.max(1, Math.floor((W - padL) / 52)));
  let svg = `<svg viewBox="0 0 ${W} ${Ht}" width="${W}" height="${Ht}" role="img" aria-label="Average sentiment per hour">`;
  for (const v of [maxAbs, 0, -maxAbs]) svg += `<line class="${v === 0 ? 'zero' : 'grid'}" x1="${padL}" x2="${W - padR}" y1="${y(v)}" y2="${y(v)}"></line><text x="${padL - 5}" y="${y(v) + 3}" text-anchor="end">${v === 0 ? '0' : fmt(v)}</text>`;
  tlBuckets.forEach((b, i) => {
    const x = padL + i * bw + gap / 2, w = Math.max(2, bw - gap);
    if (b.n) { const y0 = y(0), y1 = y(b.avg); let top = Math.min(y0, y1), h = Math.abs(y1 - y0); if (h < 2) { h = 2; top = y0 - 1; } svg += `<rect class="${b.avg > 0.05 ? 'b-up' : b.avg < -0.05 ? 'b-dn' : 'b-ne'}" x="${x}" y="${top}" width="${w}" height="${h}" rx="${Math.min(3, w / 3)}"></rect>`; }
    if (i % step === 0) svg += `<text x="${padL + i * bw + bw / 2}" y="${Ht - 6}" text-anchor="middle">${lbl(b.k)}</text>`;
    svg += `<rect class="hit" data-i="${i}" x="${padL + i * bw}" y="${padT}" width="${bw}" height="${Ht - padT - padB}"></rect>`;
  });
  box.innerHTML = svg + '</svg>';
}

function renderFocus(its) {
  const f = $('focus');
  if (!S.focus) { f.hidden = true; return; }
  const a = E.aggregate(its).find(x => x.sym === S.focus), e = ent(S.focus), on = S.watch.includes(S.focus);
  f.hidden = false;
  const outEl = $('focus-out');
  const keep = outEl && outEl.dataset.sym === S.focus ? outEl.outerHTML : `<div class="focus-out" id="focus-out" data-sym="${esc(S.focus)}"></div>`;
  f.innerHTML = `<span class="sym">${esc(S.focus)}</span><span class="sub" style="white-space:normal">${esc(e.name)} · ${esc(e.sector)}</span>${a ? `<span class="pill ${a.avg > 0.05 ? 'bull' : a.avg < -0.05 ? 'bear' : 'neu'}">${fmt(a.avg)} avg · ${a.n} ${a.n === 1 ? 'headline' : 'headlines'}</span>` : ''}<button class="star" data-star="${esc(S.focus)}" aria-pressed="${on}" style="font-size:13px">${on ? '★ On watchlist' : '☆ Add to watchlist'}</button><span class="spacer"></span>${S.cfg.features.ai ? `<button class="btn ai" data-act="outlook" style="padding:6px 12px">AI outlook for ${esc(S.focus)}</button>` : ''}<button class="x" data-act="unfocus" aria-label="Show all stocks">×</button>${keep}`;
}

function renderAccount() {
  const box = $('acct'); const f = S.cfg.features;
  if (!f.auth) { box.innerHTML = ''; return; }
  if (!S.me) { box.innerHTML = `<button class="btn primary" data-act="signin" style="padding:6px 14px">Sign in</button>`; return; }
  const pro = S.me.plan === 'pro';
  box.innerHTML = `<button class="btn" data-act="menu" aria-haspopup="true" aria-expanded="false" style="padding:6px 12px">${pro ? '<span class="badge pro">Pro</span>' : '<span class="badge">Free</span>'}<span style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(S.me.email)}</span></button>`;
}
function openMenu(btn) {
  closeMenu();
  const pro = S.me.plan === 'pro', u = S.me.usage;
  const m = document.createElement('div'); m.className = 'acct-menu'; m.id = 'acct-menu';
  m.innerHTML = `<div class="who"><b>${esc(S.me.email)}</b>${pro ? 'Pro plan' : 'Free plan'} · AI credits today ${u.ai.used}/${u.ai.limit}${pro ? ` · API calls ${u.api.used}/${u.api.limit}` : ''}</div>`
    + (pro ? (S.cfg.features.payments && S.me.billing ? `<button data-act="portal">Manage billing</button>` : '') + `<button data-act="apikey">API key</button>` : `<button data-act="upgrade">Upgrade to Pro</button>`)
    + `<button data-act="signout">Sign out</button>`;
  $('acct').appendChild(m); btn.setAttribute('aria-expanded', 'true');
}
function closeMenu() { const m = $('acct-menu'); if (m) m.remove(); const b = document.querySelector('[data-act="menu"]'); if (b) b.setAttribute('aria-expanded', 'false'); }

// ---------- Modals ----------
let lastFocus = null;
function openModal(html, wide = false) {
  lastFocus = document.activeElement;
  $('modal-card').className = 'modal-card' + (wide ? ' wide' : '');
  $('modal-card').innerHTML = `<div class="panel-head" style="margin-bottom:6px"><span></span><button class="x" data-act="close-modal" aria-label="Close">×</button></div>` + html;
  $('modal').hidden = false;
  const first = $('modal-card').querySelector('input, button.primary, button:not(.x)'); if (first) first.focus();
}
function closeModal() { $('modal').hidden = true; $('modal-card').innerHTML = ''; if (lastFocus) lastFocus.focus(); }
function signInModal(reason = '') {
  if (!S.cfg.features.auth) return;
  openModal(`<h2 id="modal-title">Sign in to MoodTape</h2><p>${esc(reason || 'Sync your watchlist and unlock AI analysis.')}</p>
    <form id="signin-form"><div class="field"><label for="si-email">Email</label><input class="input" id="si-email" type="email" required autocomplete="email" placeholder="you@example.com"></div>
    <button class="btn primary block" id="si-go">Email me a sign-in link</button></form>
    ${S.cfg.supabase && S.cfg.supabase.google ? `<div class="or">or</div><button class="btn block" data-act="google">Continue with Google</button>` : ''}
    <p class="hint" style="margin-top:14px">By signing in you agree to the <a href="/legal#terms">Terms</a> and <a href="/legal#privacy">Privacy policy</a>.</p>`);
}
function upgradeModal(reason = '') {
  const P = S.cfg.plans;
  if (!S.cfg.features.payments) { toast('Upgrades are not available yet.'); return; }
  openModal(`<h2 id="modal-title">Upgrade to MoodTape Pro</h2><p>${esc(reason || 'More AI, a bigger watchlist, CSV export and API access.')}</p>
    <div class="plans">
      <div class="plan"><h3>Free</h3><div class="price">$0</div><ul><li>Live news sentiment</li><li>Instant scoring engine</li><li>${P.free.watchlist} watchlist stocks</li><li>${P.free.aiDaily} AI credits a day</li><li class="no">CSV export</li><li class="no">REST API</li></ul></div>
      <div class="plan pro"><h3>Pro</h3><div class="price">${esc(P.pro.price || '')}</div><ul><li>Everything in Free</li><li>${P.pro.aiDaily} AI credits a day</li><li>${P.pro.watchlist} watchlist stocks</li><li>CSV export</li><li>REST API, ${P.pro.apiDaily} calls a day</li></ul>
      <button class="btn primary block" data-act="checkout">Continue to payment</button></div>
    </div><p class="hint" style="margin-top:12px">Cancel anytime from Manage billing. Payments are handled by Stripe.</p>`, true);
}
async function apiKeyModal() {
  openModal(`<h2 id="modal-title">Your API key</h2><p>Use it to pull sentiment into your own app, sheet or bot. See the <a href="/docs" target="_blank">API docs</a>.</p>
    <div id="key-area">${S.me.apiKeyHint ? `<div class="keybox">mt_••••••••••••••••••••••••••••••••••••${esc(S.me.apiKeyHint)}</div><p class="hint">For security the full key is shown only once, when created.</p>` : '<p class="hint">You have no API key yet.</p>'}</div>
    <div class="panel-row"><button class="btn primary" data-act="newkey">${S.me.apiKeyHint ? 'Replace key' : 'Create key'}</button>${S.me.apiKeyHint ? '<button class="btn" data-act="revokekey">Revoke key</button>' : ''}</div>`);
}

// ---------- AI ----------
function aiError(e) {
  if (e.status === 401) { signInModal('Sign in to use AI analysis.'); return; }
  if (e.status === 402 && e.code === 'quota') { if (S.me && S.me.plan !== 'pro') upgradeModal(e.message); else toast(e.message); return; }
  if (e.code === 'ai_not_configured') { S.cfg.features.ai = false; render(); }
  toast(e.message || 'The AI request did not finish. Try again.');
}
function busy(on, msg = '') { $('b-ai').disabled = $('b-brief').disabled = on; $('b-stop').hidden = !on; $('status').textContent = msg; }
async function runAI() {
  if (S.cfg.features.auth && !S.me) return signInModal('Sign in to use AI analysis.');
  const todo = feedItems().filter(i => !i.ai).slice(0, 25);
  if (!todo.length) { toast('Every headline in view already has an AI score.'); return; }
  ctl = { aborted: false }; const my = ctl;
  busy(true, `AI is reading ${todo.length} headlines…`);
  try {
    const d = await api('/api/ai', { method: 'POST', body: { mode: 'score', headlines: todo.map(i => ({ id: i.id, text: i.text, source: i.source })) } });
    if (my.aborted) return;
    let n = 0;
    for (const [id, r] of Object.entries(d.results || {})) { S.aiCache[id] = r; n++; }
    pruneAiCache(); store.set('mt.ai', S.aiCache);
    if (d.usage && S.me) S.me.usage = d.usage;
    toast(n ? `AI scored ${n} headlines.` : 'The AI did not return scores. Try again.');
  } catch (e) { if (!my.aborted) aiError(e); }
  finally { if (ctl === my) { busy(false); ctl = null; } render(); }
}
function pruneAiCache() { const keys = Object.keys(S.aiCache); if (keys.length > 800) for (const k of keys.slice(0, keys.length - 800)) delete S.aiCache[k]; }
const scored = list => list.map(it => { const e = eff(it); return { id: it.id, text: it.text, source: it.source, score: e.score, label: e.label, syms: allSyms(it) }; });
function renderBrief(text, el) {
  let html = '', inList = false;
  for (let l of text.split(/\r?\n/)) {
    l = l.replace(/\*\*/g, '').replace(/^#+\s*/, '').trim(); if (!l) continue;
    if (/^[-•*]\s+/.test(l)) { if (!inList) { html += '<ul>'; inList = true; } html += `<li>${esc(l.replace(/^[-•*]\s+/, ''))}</li>`; continue; }
    if (inList) { html += '</ul>'; inList = false; }
    const hm = /^([A-Z][A-Za-z' ]{2,30}):\s*(.*)$/.exec(l);
    if (hm) { html += `<h4>${esc(hm[1])}</h4>`; if (hm[2]) html += `<p>${esc(hm[2])}</p>`; } else html += `<p>${esc(l)}</p>`;
  }
  if (inList) html += '</ul>';
  el.innerHTML = html;
}
async function runBrief() {
  if (S.cfg.features.auth && !S.me) return signInModal('Sign in to get the AI market brief.');
  const its = marketItems().sort((a, b) => b.time - a.time);
  if (!its.length) { toast('No headlines to summarise yet.'); return; }
  const m = E.mood(its);
  $('brief').hidden = false; $('brief-body').innerHTML = '<p class="thinking">Writing the brief…</p>';
  ctl = { aborted: false }; const my = ctl; busy(true, 'Writing market brief…');
  try {
    const d = await api('/api/ai', { method: 'POST', body: { mode: 'brief', headlines: scored(its.slice(0, 60)), context: { market: S.market, mood: m.mood, net: m.net } } });
    if (my.aborted) return;
    renderBrief(d.text || '', $('brief-body')); if (d.usage && S.me) S.me.usage = d.usage;
  } catch (e) { if (!my.aborted) { $('brief').hidden = true; aiError(e); } }
  finally { if (ctl === my) { busy(false); ctl = null; } }
}
async function runOutlook() {
  if (S.cfg.features.auth && !S.me) return signInModal('Sign in to get AI stock outlooks.');
  const sym = S.focus; if (!sym) return;
  const its = marketItems().filter(it => allSyms(it).includes(sym)).sort((a, b) => b.time - a.time);
  const out = $('focus-out'); if (!out) return;
  if (!its.length) { out.textContent = 'No headlines for this stock yet.'; return; }
  out.dataset.sym = sym; out.innerHTML = '<span class="thinking">Reading the headlines…</span>';
  ctl = { aborted: false }; const my = ctl; busy(true, `Reading ${sym} headlines…`);
  try {
    const d = await api('/api/ai', { method: 'POST', body: { mode: 'outlook', symbol: sym, headlines: scored(its.slice(0, 25)) } });
    if (my.aborted) return;
    out.textContent = d.text || ''; if (d.usage && S.me) S.me.usage = d.usage;
  } catch (e) { if (!my.aborted) { out.textContent = ''; aiError(e); } }
  finally { if (ctl === my) { busy(false); ctl = null; } }
}

// ---------- Your own headlines ----------
function parseTime(s) {
  s = String(s || '').trim(); if (!s) return null;
  const hm = /^(\d{1,2})[:.](\d{2})\s*(am|pm)?$/i.exec(s);
  if (hm) { let h = +hm[1]; const mi = +hm[2]; if (hm[3]) { if (/pm/i.test(hm[3]) && h < 12) h += 12; if (/am/i.test(hm[3]) && h === 12) h = 0; } const d = new Date(); d.setHours(h, mi, 0, 0); if (d.getTime() > Date.now() + 60000) d.setDate(d.getDate() - 1); return d.getTime(); }
  const t = Date.parse(s); return isNaN(t) ? null : t;
}
function parseLines(txt) {
  const out = [];
  for (let line of txt.split(/\r?\n/)) {
    line = line.trim().replace(/^(?:[-•*]|\d{1,2}[.)])\s+/, '');
    if (line.length < 12) continue;
    const parts = line.split(/\s+\|\s+/);
    let time = null, source = '', text = line;
    if (parts.length >= 3) { time = parseTime(parts[0]); source = parts[1]; text = parts.slice(2).join(' | '); if (time === null) { source = parts[0]; text = parts.slice(1).join(' | '); } }
    else if (parts.length === 2) { const t = parseTime(parts[0]); if (t !== null) time = t; else source = parts[0]; text = parts[1]; }
    out.push({ text, source, time });
  }
  return out;
}
function parseCSV(txt) {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < txt.length; i++) {
    const ch = txt[i];
    if (q) { if (ch === '"') { if (txt[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && txt[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += ch;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  const clean = rows.filter(r => r.some(c => c.trim())); if (!clean.length) return [];
  const head = clean[0].map(c => c.trim().toLowerCase());
  let hi = head.findIndex(h => /headline|title|news|text/.test(h));
  const si = head.findIndex(h => /source|publisher|site|outlet/.test(h));
  const ti = head.findIndex(h => /time|date|published|datetime/.test(h));
  let body = clean; if (hi >= 0) body = clean.slice(1); else hi = 0;
  return body.map(r => ({ text: (r[hi] || '').trim(), source: si >= 0 ? (r[si] || '').trim() : '', time: (ti >= 0 && parseTime(r[ti] || '')) || null })).filter(r => r.text.length >= 12);
}
function addOwn(rows) {
  const seen = new Set(items().map(i => i.text.toLowerCase())); const now = Date.now(); let n = 0;
  rows.forEach((r, i) => {
    const text = r.text.replace(/\s+/g, ' ').trim(); const k = text.toLowerCase();
    if (seen.has(k)) return; seen.add(k);
    const a = E.analyze(text);
    S.own.unshift({ id: 'own-' + now.toString(36) + '-' + i, text, source: r.source || '', time: r.time || now - i * 1000, mkt: '', lex: a.lex, syms: a.syms, own: true });
    n++;
  });
  S.own = S.own.slice(0, 300); store.set('mt.own', S.own); render();
  return n;
}

// ---------- Watchlist ----------
async function toggleWatch(sym) {
  const on = S.watch.includes(sym);
  const next = on ? S.watch.filter(s => s !== sym) : [...S.watch, sym];
  const max = limits().watchlist;
  if (!on && next.length > max) {
    if (S.cfg.features.auth && (!S.me || S.me.plan !== 'pro')) { if (!S.me) signInModal(`Free accounts can follow ${max} stocks. Sign in to sync your watchlist.`); else upgradeModal(`Your Free plan follows up to ${max} stocks. Pro follows ${S.cfg.plans.pro.watchlist}.`); }
    else toast(`Your watchlist is full (${max} stocks).`);
    return;
  }
  const prev = S.watch; S.watch = next; store.set('mt.watch', S.watch); render();
  if (S.me) { try { await api('/api/watchlist', { method: 'PUT', body: { symbols: next } }); } catch (e) { S.watch = prev; store.set('mt.watch', prev); render(); toast(e.message); } }
}

// ---------- CSV ----------
function exportCSV() {
  if (!isPro()) { if (!S.me) return signInModal('CSV export is part of Pro. Sign in to upgrade.'); return upgradeModal('CSV export is part of Pro.'); }
  const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
  const rows = [['time', 'source', 'headline', 'link', 'tickers', 'sector', 'score', 'label', 'engine', 'impact', 'horizon', 'ai_reason']];
  for (const it of feedItems()) { const e = eff(it); rows.push([new Date(it.time).toISOString(), it.source, it.text, it.link || '', allSyms(it).join(' '), itemSector(it) || '', e.score.toFixed(3), e.label, e.src === 'ai' ? 'AI' : 'Instant', it.ai ? it.ai.impact : '', it.ai ? it.ai.horizon : '', it.ai ? it.ai.reason : '']); }
  const blob = new Blob(['﻿' + rows.map(r => r.map(q).join(',')).join('\n')], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `moodtape-${new Date().toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  toast(`Exported ${rows.length - 1} headlines.`);
}

// ---------- Sample data (only when live news cannot be reached) ----------
function sampleItems() {
  const now = Date.now(), m = 60000;
  return [
    [25, 'Sample', 'Reliance Industries Q2 net profit jumps 12%, beats street estimates on strong retail and Jio growth', 'IN'],
    [40, 'Sample', 'TCS shares fall 3% after weak deal wins and muted revenue guidance', 'IN'],
    [55, 'Sample', 'Nvidia shares soar 7% on record data-centre revenue, raises outlook', 'US'],
    [70, 'Sample', 'Infosys raises FY27 revenue guidance, announces ₹18,000 crore buyback', 'IN'],
    [100, 'Sample', 'Analysts upgrade HDFC Bank to Buy, price target raised on stable asset quality', 'IN'],
    [125, 'Sample', 'SEBI probe into Adani Group disclosures widens; Adani Enterprises slides 6%', 'IN'],
    [135, 'Sample', 'Apple iPhone sales miss estimates in China; stock slips 2% after hours', 'US'],
    [150, 'Sample', 'Tata Motors JLR sales slump 9% in Europe amid tariff concerns', 'IN'],
    [190, 'Sample', 'Fed officials signal no rush to cut rates as inflation stays sticky', 'US'],
    [200, 'Sample', 'FII selling continues for fifth straight session; Nifty ends lower', 'IN'],
    [240, 'Sample', 'RBI keeps repo rate unchanged, signals room for rate cut as inflation eases', 'IN'],
    [270, 'Sample', 'Tata Steel shares rally 4% on strong China demand and higher steel prices', 'IN'],
    [300, 'Sample', 'Sun Pharma gets USFDA warning letter for Halol plant', 'IN'],
    [310, 'Sample', 'Microsoft Azure growth accelerates; analysts see strong AI tailwinds', 'US'],
    [330, 'Sample', 'Zomato surges to record high after quarterly loss narrows sharply', 'IN'],
    [360, 'Sample', 'L&T bags mega order worth over ₹10,000 crore from Middle East client', 'IN'],
    [380, 'Sample', 'Paytm shares tumble after RBI imposes penalty over KYC lapses', 'IN'],
    [410, 'Sample', 'S&P 500 closes at record high as tech rally broadens', 'US'],
    [460, 'Sample', 'ITC margins under pressure as input costs climb', 'IN'],
    [480, 'Sample', 'Bank Nifty hits all-time high as private lenders gain', 'IN'],
    [510, 'Sample', 'Wipro fails to beat estimates; margins decline for second quarter', 'IN'],
    [530, 'Sample', 'Gold climbs to record as investors seek safety', 'US'],
    [570, 'Sample', 'Rupee weakens against dollar as crude oil prices surge', 'IN'],
    [590, 'Sample', 'Intel slumps after weak guidance, plans layoffs', 'US'],
    [15, 'Sample', 'Nifty, Sensex open flat ahead of US inflation data', 'IN']
  ].map(([mins, source, text, mkt], i) => { const a = E.analyze(text); return { id: 'sample-' + i, text, source, link: '', time: now - mins * m, mkt, lex: a.lex, syms: a.syms }; });
}

let toastT;
function toast(msg) { const t = $('toast'); t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => t.hidden = true, 3600); }

// ---------- Events ----------
function setFocus(sym) { S.focus = S.focus === sym ? null : sym; S.showAll = 30; render(); if (S.focus) $('focus').scrollIntoView({ behavior: reduced ? 'auto' : 'smooth', block: 'nearest' }); }
document.addEventListener('click', async e => {
  if (!e.target.closest('#acct')) closeMenu();
  if (e.target === $('modal')) return closeModal();
  const t = e.target.closest('button'); if (!t) return;
  if (t.dataset.star) return toggleWatch(t.dataset.star);
  if (t.dataset.sym) return setFocus(t.dataset.sym);
  if (t.dataset.sector) { S.sector = S.sector === t.dataset.sector ? null : t.dataset.sector; S.showAll = 30; return render(); }
  if (t.dataset.m) { S.market = t.dataset.m; S.focus = null; S.sector = null; store.set('mt.market', S.market); return render(); }
  if (t.dataset.s) { S.sent = t.dataset.s; S.showAll = 30; return render(); }
  const act = t.dataset.act;
  if (act === 'more') { S.showAll += 30; return renderFeed(); }
  if (act === 'stocks') { S.showAllStocks = !S.showAllStocks; return renderStocks(marketItems()); }
  if (act === 'unfocus') { S.focus = null; return render(); }
  if (act === 'sec-clear') { S.sector = null; return render(); }
  if (act === 'outlook') return runOutlook();
  if (act === 'signin') return signInModal();
  if (act === 'google') return googleSignIn();
  if (act === 'menu') { if ($('acct-menu')) closeMenu(); else openMenu(t); return; }
  if (act === 'signout') { closeMenu(); return signOut(); }
  if (act === 'upgrade') { closeMenu(); return upgradeModal(); }
  if (act === 'apikey') { closeMenu(); return apiKeyModal(); }
  if (act === 'close-modal') return closeModal();
  if (act === 'checkout') { t.disabled = true; t.textContent = 'Opening Stripe…'; try { const d = await api('/api/stripe/checkout', { method: 'POST' }); location.href = d.url; } catch (err) { t.disabled = false; t.textContent = 'Continue to payment'; toast(err.message); } return; }
  if (act === 'portal') { closeMenu(); try { const d = await api('/api/stripe/portal', { method: 'POST' }); location.href = d.url; } catch (err) { toast(err.message); } return; }
  if (act === 'newkey') { t.disabled = true; try { const d = await api('/api/apikey', { method: 'POST' }); S.me.apiKeyHint = d.hint; $('key-area').innerHTML = `<div class="keybox" id="the-key">${esc(d.apiKey)}</div><div class="panel-row" style="margin-bottom:10px"><button class="btn" data-act="copykey">Copy key</button></div><p class="hint">Save it now. It will not be shown again.</p>`; } catch (err) { toast(err.message); } t.disabled = false; return; }
  if (act === 'copykey') { const k = $('the-key').textContent; try { await navigator.clipboard.writeText(k); toast('API key copied.'); } catch { const r = document.createRange(); r.selectNodeContents($('the-key')); getSelection().removeAllRanges(); getSelection().addRange(r); toast('Key selected. Press Ctrl+C to copy.'); } return; }
  if (act === 'revokekey') { try { await api('/api/apikey', { method: 'DELETE' }); S.me.apiKeyHint = null; closeModal(); toast('API key revoked.'); } catch (err) { toast(err.message); } return; }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') { if (!$('modal').hidden) closeModal(); closeMenu(); } });
document.addEventListener('submit', async e => {
  if (e.target.id !== 'signin-form') return;
  e.preventDefault();
  const email = $('si-email').value.trim(), btn = $('si-go');
  btn.disabled = true; btn.textContent = 'Sending…';
  try { await sendMagicLink(email); $('modal-card').innerHTML = `<div class="panel-head"><span></span><button class="x" data-act="close-modal" aria-label="Close">×</button></div><h2 id="modal-title">Check your email</h2><p>We sent a sign-in link to <b>${esc(email)}</b>. Open it on this device to finish signing in.</p>`; }
  catch (err) { btn.disabled = false; btn.textContent = 'Email me a sign-in link'; toast(err.message); }
});
$('find').addEventListener('submit', e => { e.preventDefault(); findStock($('find-q').value); $('find-q').blur(); });
$('tl-wrap').addEventListener('pointermove', e => {
  const t = e.target.closest('.hit'), tip = $('tip');
  if (!t) { tip.hidden = true; return; }
  const b = tlBuckets[+t.dataset.i]; if (!b) return;
  const H = 3600000, f = k => new Date(k * H).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
  tip.textContent = b.n ? `${f(b.k)}–${f(b.k + 1)} · avg ${fmt(b.avg)} · ${b.n} ${b.n === 1 ? 'headline' : 'headlines'}` : `${f(b.k)}–${f(b.k + 1)} · no headlines`;
  const r = $('tl-wrap').getBoundingClientRect();
  tip.style.left = Math.max(80, Math.min(r.width - 80, e.clientX - r.left)) + 'px'; tip.style.top = (e.clientY - r.top) + 'px'; tip.hidden = false;
});
$('tl-wrap').addEventListener('pointerleave', () => { $('tip').hidden = true; });
$('b-add').onclick = () => { $('panel').hidden = !$('panel').hidden; if (!$('panel').hidden) $('inp').focus(); };
$('b-close-panel').onclick = () => { $('panel').hidden = true; };
$('b-close-brief').onclick = () => { $('brief').hidden = true; };
$('watch-only').onclick = () => { S.watchOnly = !S.watchOnly; render(); };
$('q').oninput = e => { S.q = e.target.value; S.showAll = 30; renderFeed(); };
$('sort').onchange = e => { S.sort = e.target.value; renderFeed(); };
$('b-refresh').onclick = () => loadNews();
$('b-retry').onclick = () => loadNews();
$('b-analyse').onclick = () => {
  const rows = parseLines($('inp').value);
  if (!rows.length) { toast('Paste at least one headline (12+ characters per line).'); return; }
  const n = addOwn(rows); $('inp').value = ''; $('panel').hidden = true;
  toast(n ? `Scored ${n} ${n === 1 ? 'headline' : 'headlines'}.` : 'Those headlines are already in the feed.');
};
$('file').onchange = e => {
  const f = e.target.files && e.target.files[0]; if (!f) return;
  const r = new FileReader();
  r.onload = () => {
    const txt = String(r.result || ''), first = txt.split('\n')[0] || '';
    const rows = /\.csv$/i.test(f.name) || (first.includes(',') && /headline|title/i.test(first)) ? parseCSV(txt) : parseLines(txt);
    if (!rows.length) { toast('No headlines found. Use one headline per line, or a CSV with a headline column.'); return; }
    const n = addOwn(rows); $('panel').hidden = true; toast(`Scored ${n} headlines from ${f.name}.`);
  };
  r.readAsText(f); e.target.value = '';
};
$('b-clear').onclick = function () {
  if (this.dataset.armed) { S.own = []; store.set('mt.own', []); render(); this.textContent = 'Remove my headlines'; delete this.dataset.armed; toast('Your headlines were removed.'); return; }
  this.dataset.armed = '1'; this.textContent = 'Click again to remove';
  setTimeout(() => { if (this.dataset.armed) { delete this.dataset.armed; this.textContent = 'Remove my headlines'; } }, 3000);
};
$('b-ai').onclick = runAI;
$('b-brief').onclick = runBrief;
$('b-stop').onclick = () => { if (ctl) ctl.aborted = true; ctl = null; busy(false); };
$('b-csv').onclick = exportCSV;
let rt; addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => renderTimeline(marketItems()), 150); });
setInterval(() => { if (document.visibilityState === 'visible') { setLive(); renderFeed(); } }, 60000);
setInterval(() => { if (document.visibilityState === 'visible') loadNews({ quiet: true }); }, 5 * 60000);
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && Date.now() - S.fetchedAt > 5 * 60000) loadNews({ quiet: true }); });

// ---------- Boot ----------
(async function boot() {
  drawArcs();
  $('sym-list').innerHTML = E.ENTS.map(e => `<option value="${esc(e[0])}">${esc(e[1])}</option>`).join('');
  const c = store.get('mt.liveCache', null);
  if (c && c.items && Date.now() - c.fetchedAt < 30 * 60000) { S.live = c.items; S.fetchedAt = c.fetchedAt; S.liveOk = true; }
  render();
  try { S.cfg = await api('/api/config', { auth: false }); } catch {}
  readHashSession();
  await loadMe();
  const p = new URLSearchParams(location.search);
  if (p.get('upgraded')) { toast('Welcome to Pro. Your new limits are active.'); history.replaceState(null, '', location.pathname); setTimeout(async () => { await loadMe(); render(); }, 2500); }
  if (p.get('upgrade') === 'cancelled') { toast('Upgrade cancelled. You were not charged.'); history.replaceState(null, '', location.pathname); }
  if (p.get('symbol')) findStock(p.get('symbol'));
  render();
  await loadNews();
})();
})();
