/* Landing page: live mood card + plan numbers from /api/config. */
(function () {
'use strict';
const E = window.MoodEngine, $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fmt = n => (n > 0 ? '+' : n < 0 ? '−' : '') + Math.abs(n).toFixed(2);
$('yr').textContent = new Date().getFullYear();

function arc(a0, a1, r) { const p = a => [120 + r * Math.cos(a * Math.PI / 180), 122 - r * Math.sin(a * Math.PI / 180)]; const [x0, y0] = p(a0), [x1, y1] = p(a1); return `M${x0.toFixed(2)} ${y0.toFixed(2)} A${r} ${r} 0 0 1 ${x1.toFixed(2)} ${y1.toFixed(2)}`; }
const cols = ['var(--bear)', 'color-mix(in oklab, var(--bear) 55%, var(--neutral))', 'var(--neutral)', 'color-mix(in oklab, var(--bull) 55%, var(--neutral))', 'var(--bull)'];
$('arcs').innerHTML = cols.map((c, i) => `<path class="seg-arc" style="stroke:${c}" d="${arc(180 - i * 36 - 1.2, 180 - (i + 1) * 36 + 1.2, 96)}"></path>`).join('');

function show(items, live) {
  const m = E.mood(items);
  $('needle').style.transform = `rotate(${(m.mood - 50) * 1.8}deg)`;
  $('lc-mood').textContent = m.mood;
  $('lc-label').textContent = m.label;
  $('lc-label').style.color = m.mood > 60 ? 'var(--bull-ink)' : m.mood < 40 ? 'var(--bear-ink)' : '';
  $('lc-meta').textContent = `${items.length} headlines · net ${fmt(m.net)}`;
  $('lc-live').classList.toggle('off', !live);
  $('lc-live').lastElementChild.textContent = live ? 'Live' : 'Sample';
  const top = [...items].sort((a, b) => Math.abs(E.effective(b).score) - Math.abs(E.effective(a).score)).slice(0, 4).sort((a, b) => b.time - a.time);
  $('lc-list').innerHTML = top.map(it => { const e = E.effective(it), c = e.label === 'Bullish' ? 'bull' : e.label === 'Bearish' ? 'bear' : 'neu'; return `<div class="lh"><span class="pill ${c}">${fmt(e.score)}</span><span>${esc(it.text)}<span class="src">${esc(it.source || '')}${it.syms && it.syms.length ? ' · ' + esc(it.syms.join(', ')) : ''}</span></span></div>`; }).join('');
}
const sample = () => ['Infosys raises FY27 revenue guidance, announces buyback', 'TCS shares fall 3% after weak deal wins and muted revenue guidance', 'Bank Nifty hits all-time high as private lenders gain', 'Fed officials signal no rush to cut rates as inflation stays sticky', 'Tata Steel shares rally 4% on strong China demand', 'Sun Pharma gets USFDA warning letter for Halol plant']
  .map((t, i) => ({ text: t, source: 'Sample headline', time: Date.now() - i * 6e5, ...E.analyze(t) }));

fetch('/api/news?market=ALL').then(r => r.ok ? r.json() : Promise.reject()).then(d => { if (d.items && d.items.length) show(d.items, true); else show(sample(), false); }).catch(() => show(sample(), false));
fetch('/api/config').then(r => r.ok ? r.json() : null).then(c => {
  if (!c || !c.plans) return;
  const P = c.plans;
  $('p-free-watch').textContent = P.free.watchlist; $('p-free-ai').textContent = P.free.aiDaily;
  $('p-pro-watch').textContent = P.pro.watchlist; $('p-pro-ai').textContent = P.pro.aiDaily; $('p-pro-api').textContent = P.pro.apiDaily;
  if (P.pro.price) { const m = /^(.+?)\s*(\/.*)$/.exec(P.pro.price); $('p-price').innerHTML = m ? `${esc(m[1])} <small>${esc(m[2])}</small>` : esc(P.pro.price); }
}).catch(() => {});
})();
